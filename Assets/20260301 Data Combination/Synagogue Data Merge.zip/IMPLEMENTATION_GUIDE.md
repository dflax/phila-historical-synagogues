# COMPLETE DATA MERGE - IMPLEMENTATION GUIDE

## Overview

This guide walks you through merging rabbi and address data from the new spreadsheet into your Supabase database.

## What's Included

### SQL Files
1. **`complete_merge.sql`** (215 KB) - Complete merge script with:
   - Schema changes (add start_year/end_year to addresses)
   - 28 rabbi updates (add year ranges)
   - 431 rabbi inserts (new rabbis)
   - 63 address updates (add year ranges)
   - 157 address inserts (new historical addresses)
   - Verification queries

### Data Files
2. **`addresses_to_geocode.csv`** - 157 new addresses needing lat/lon coordinates

### Analysis Files  
3. **`RABBI_MERGE_ANALYSIS.md`** - Complete rabbi merge analysis
4. **`ADDRESS_MERGE_ANALYSIS.md`** - Complete address merge analysis
5. CSV files with detailed breakdowns

---

## STEP-BY-STEP IMPLEMENTATION

### Step 1: Backup Your Database (IMPORTANT!)

Before running ANY SQL, create a backup:

1. In Supabase Dashboard, go to **Database** → **Backups**
2. Click **"Create backup"**
3. Wait for completion
4. Take note of backup ID

**Why?** If anything goes wrong, you can restore to this point.

---

### Step 2: Run the Merge SQL

1. Open **Supabase SQL Editor**
2. Click **"New query"**
3. Open `complete_merge.sql` in a text editor
4. **Copy the ENTIRE contents**
5. **Paste into Supabase SQL Editor**
6. Click **"Run"** (or Ctrl/Cmd + Enter)

**Expected:** 
- Runtime: ~30-60 seconds
- Result: "Success. No rows returned"

---

### Step 3: Verify the Merge

Run the verification queries at the bottom of the SQL file.

Expected results:
- Total rabbis: ~801 (was 370)
- Rabbis with years: ~468 (was 111)
- Total addresses: ~609 (was 452)
- Addresses with years: ~220 (was 0!)

---

### Step 4: Geocode New Addresses

Choose one option:

**Option A: Google Geocoding API Script** (I'll create this)
**Option B: Batch geocoding service** (geocod.io, smarty.com)
**Option C: Do later**

Let me know which you prefer!

---

## SUCCESS METRICS

After completion:
- ✅ 801 rabbis (up from 370)
- ✅ 58% with complete years (up from 3%!)
- ✅ 609 addresses (up from 452)
- ✅ 100% with temporal data (up from 0%!)

Ready to proceed? Run Step 1 (Backup) and Step 2 (SQL)!
