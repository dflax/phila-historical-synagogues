# RABBI DATA MERGE ANALYSIS REPORT
Generated: March 1, 2026

## EXECUTIVE SUMMARY

### Current State
- **Rabbis in database:** 370
- **With complete year data:** 11 (3%)
- **Missing all years:** 259 (70%)

### Merge Results
- **✓ MATCHES:** 28 rabbis (found in both datasets)
- **+ NEW ADDITIONS:** 431 rabbis (from new spreadsheet)
- **= KEEP AS-IS:** 342 rabbis (only in current DB)

### After Merge
- **Total rabbis:** 801 (370 current + 431 new)
- **With complete years:** ~468 (58% improvement!)
- **Synagogues affected:** 120

---

## DETAILED BREAKDOWN

### 1. MATCHED RABBIS (28 records)
These rabbis exist in both datasets. Most need year range updates:

**Year Range Improvements:**
- 26 records will get year ranges added
- 2 records have conflicting years (need manual review)

**Sample Matches:**
| Synagogue | Rabbi | Current Years | New Years | Action |
|-----------|-------|---------------|-----------|--------|
| Adath Jeshurun | Seymour Rosenbloom | None-None | 1978-2010 | UPDATE years |
| Beth Ami | Moshe Goldman | None-None | 1989-2008 | UPDATE years |
| Beth El of Bucks County | Jeff Pivo | None-None | 2003-2010 | UPDATE years |
| Main Line Reform Temple | Theodore H. Gordon | 1953-1972 | 1961-1979 | REVIEW conflict |
| Har Zion Temple | Simon Greenberg | 1925-None | 1936 | UPDATE end year |

**Recommendation:** 
- UPDATE all 26 with missing years
- MANUALLY REVIEW 2 with conflicting years

---

### 2. NEW RABBI ADDITIONS (431 records)

These rabbis are NOT in your current database and will be added:

**Top Synagogues Getting New Rabbis:**
| Synagogue | New Rabbis |
|-----------|------------|
| Bristol Jewish Center | +20 |
| Temple Shalom | +18 |
| Beth Israel | +16 |
| Or Shalom | +15 |
| Beth El | +12 |
| Beth Am Israel | +10 |
| Adath Shalom | +10 |

**Sample New Additions:**
| Synagogue | Rabbi | Years |
|-----------|-------|-------|
| Adath Israel | Martin Berkowitz | 1949-1963 |
| Adath Israel | Frederic Kazan | 1982-2001 |
| Adath Israel | Steven C. Wernick | 2002-2006 |
| Adath Jeshurun | Max D. Klein | 1936-1960 |
| Adath Jeshurun | Yaakov G. Rosenberg | 1961-1977 |

**Note:** Many synagogues will get complete rabbi succession histories!

---

### 3. RABBIS TO KEEP AS-IS (342 records)

These rabbis are only in your current database (not in new spreadsheet):
- Keep all existing data
- No changes needed
- Preserve any manual edits or notes

---

## DATA QUALITY IMPROVEMENTS

### Year Range Completeness

**BEFORE:**
- Rabbis with start_year: 111 (30%)
- Rabbis with end_year: 11 (3%)
- Rabbis with both years: 11 (3%)
- Missing all years: 259 (70%)

**AFTER MERGE:**
- Rabbis with start_year: ~542 (68%)
- Rabbis with end_year: ~442 (55%)
- Rabbis with both years: ~442 (55%)
- Missing all years: ~259 (32%)

**Improvement:** From 3% complete to 55% complete! 🎉

---

## MERGE STRATEGY

### Phase 1: UPDATE Existing Records (28 rabbis)
- Add year ranges to matched rabbis
- Preserve existing notes and metadata
- Manual review for 2 conflicting records

### Phase 2: INSERT New Records (431 rabbis)
- Match synagogue by normalized name
- Parse year ranges (handle single years, ranges, 2010→2017 adjustment)
- Set all as approved=true
- Link to correct synagogue_id

### Phase 3: Verification
- Verify all inserts linked to correct synagogues
- Check for duplicate rabbi entries
- Validate year ranges make sense

---

## SYNAGOGUE NAME MATCHING

**Normalization Rules Applied:**
- Remove "Temple" prefix
- Remove "Congregation" prefix
- Remove punctuation (except hyphens)
- Lowercase for comparison
- Handle common variations

**Examples:**
- "Temple Adath Israel" → "adath israel"
- "Congregation Beth El" → "beth el"
- "Adath Israel of the Main Line" → "adath israel of the main line"

**Match Success Rate:** 
- Direct matches: ~85%
- Fuzzy matches (>80% similar): ~10%
- No match found: ~5% (these were excluded)

---

## NOTABLE PATTERNS

### 1. Complete Rabbi Succession
Several synagogues will now have complete rabbi succession histories:
- **Adath Jeshurun:** 3 rabbis from 1936-2010
- **Adath Shalom:** 10 rabbis from 1961-1991
- **Temple Shalom:** 18 rabbis over its history
- **Bristol Jewish Center:** 20 rabbis over its history

### 2. Long-Serving Rabbis
Rabbis who served 20+ years:
- Max D. Klein (Adath Jeshurun): 1936-1960 (24 years)
- Seymour Rosenbloom (Adath Jeshurun): 1978-2010 (32 years!)
- Frederic Kazan (Adath Israel): 1982-2001 (19 years)

### 3. Recent Activity
The new data goes up to 2010 (adjusted to 2017), showing:
- Current rabbis still serving
- Recent transitions
- Recent closures

---

## NEXT STEPS

### Option A: Full Automatic Merge (Recommended)
1. Generate SQL UPDATE statements for 26 matched rabbis
2. Generate SQL INSERT statements for 431 new rabbis
3. Review the 2 conflicting matches manually
4. Execute SQL in Supabase
5. Verify results

### Option B: Phased Approach
1. Start with UPDATEs only (28 records)
2. Review results
3. Then do INSERTs in batches by synagogue
4. Verify each batch

### Option C: Sample Test First
1. Pick 5 synagogues with many additions
2. Do those first as a test
3. Verify they look correct on the website
4. Then proceed with full merge

---

## RISKS & MITIGATIONS

### Risk 1: Wrong Synagogue Matches
**Mitigation:** Name normalization with 80% similarity threshold. Manual review of edge cases.

### Risk 2: Duplicate Rabbis
**Mitigation:** Check if rabbi+synagogue+years already exists before inserting.

### Risk 3: Year Range Conflicts
**Mitigation:** Manual review of 2 known conflicts. Preserve existing data where possible.

### Risk 4: Data Loss
**Mitigation:** 
- Keep all 342 existing rabbis that aren't matched
- Never delete, only add/update
- Can easily roll back with SQL

---

## RECOMMENDATION

**Proceed with Option A (Full Automatic Merge)** because:

1. ✅ **High confidence in matches** - 85% direct, 10% fuzzy (>80% similar)
2. ✅ **Massive improvement** - 3% → 55% completeness
3. ✅ **Low risk** - No deletions, only additions/updates
4. ✅ **Easy rollback** - Can delete all records created after today's timestamp
5. ✅ **Complete histories** - Many synagogues will have full rabbi succession

**Manual review needed for only 2 records with conflicting years.**

---

## FILES GENERATED

1. **rabbi_matches.csv** - 28 matched rabbis needing review
2. **rabbi_new_additions.csv** - 431 new rabbis to add
3. **rabbi_updates_needed.csv** - UPDATE statements preview
4. **rabbi_inserts_needed.csv** - INSERT statements preview
5. **new_rabbis_parsed.csv** - Parsed new spreadsheet data

---

## APPROVAL NEEDED

Before generating final SQL:

**Question 1:** Do you want to proceed with all 431 insertions?
**Question 2:** Should we handle the 2 year conflicts automatically (newer data wins) or manually?
**Question 3:** Any specific synagogues you want to exclude or handle specially?

Once approved, I'll generate the complete SQL import script!
