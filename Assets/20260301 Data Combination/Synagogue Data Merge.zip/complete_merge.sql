-- ============================================================================
-- PHILADELPHIA HISTORICAL SYNAGOGUES - COMPLETE DATA MERGE
-- ============================================================================
-- Generated: March 1, 2026
-- 
-- This script merges rabbi and address data from the new spreadsheet
-- 
-- Summary:
--   - Schema changes: Add start_year/end_year to addresses
--   - Rabbi updates: 28 records
--   - Rabbi inserts: 431 records
--   - Address updates: 63 records
--   - Address inserts: 157 records
-- ============================================================================

-- ============================================================================
-- SECTION 1: DATABASE SCHEMA CHANGES
-- ============================================================================
-- Add temporal tracking to addresses table

ALTER TABLE public.addresses 
  ADD COLUMN IF NOT EXISTS start_year INTEGER,
  ADD COLUMN IF NOT EXISTS end_year INTEGER;

-- Update is_current logic based on end_year
-- An address is current if end_year is NULL or >= 2024
UPDATE public.addresses
SET is_current = CASE 
  WHEN end_year IS NULL THEN true
  WHEN end_year >= 2024 THEN true
  ELSE false
END
WHERE end_year IS NOT NULL;


-- ============================================================================
-- SECTION 2: RABBI DATA - UPDATES (Add Year Ranges)
-- ============================================================================
-- Updating 28 rabbi records with year ranges

-- 1. Seymour Rosenbloom at Adath Jeshurun
UPDATE public.rabbis
SET start_year = 1978,
    end_year = 2017
WHERE name = 'Seymour Rosenbloom'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Adath Jeshurun'
    LIMIT 1
  );

-- 2. Moshe Goldman at Beth Ami
UPDATE public.rabbis
SET start_year = 1989,
    end_year = 2008
WHERE name = 'Moshe Goldman'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Ami'
    LIMIT 1
  );

-- 3. Michael Bernstein at Beth Am Israel
UPDATE public.rabbis
SET start_year = 2004,
    end_year = 2007
WHERE name = 'Michael Bernstein'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Am Israel'
    LIMIT 1
  );

-- 4. Jeff Pivo at Beth El of Bucks County
UPDATE public.rabbis
SET start_year = 2003,
    end_year = 2017
WHERE name = 'Jeff Pivo'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth El of Bucks County'
    LIMIT 1
  );

-- 5. Shlomo Caplan at Beth HaMedrash
UPDATE public.rabbis
SET start_year = 1977,
    end_year = 2008
WHERE name = 'Shlomo Caplan'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth HaMedrash'
    LIMIT 1
  );

-- 6. Sherman Novoseller at Beth Tovim
UPDATE public.rabbis
SET start_year = 1964,
    end_year = 1981
WHERE name = 'Sherman Novoseller'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Tovim'
    LIMIT 1
  );

-- 7. Erwin Weiss at B'nai Israel of Olney
UPDATE public.rabbis
SET start_year = 1955,
    end_year = 1955
WHERE name = 'Erwin Weiss'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'B''nai Israel of Olney'
    LIMIT 1
  );

-- 8. Elliot Strom at Shir Ami-Bucks County Jewish Congregation
UPDATE public.rabbis
SET start_year = 1979,
    end_year = 2017
WHERE name = 'Elliot Strom'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Shir Ami-Bucks County Jewish Congregation'
    LIMIT 1
  );

-- 9. Victor Solomon at Ezrath Israel
UPDATE public.rabbis
SET start_year = 1955,
    end_year = 1963
WHERE name = 'Victor Solomon'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Ezrath Israel'
    LIMIT 1
  );

-- 10. Sanford Hahn at Germantown Jewish Center
UPDATE public.rabbis
SET start_year = 1978,
    end_year = 1993
WHERE name = 'Sanford Hahn'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Germantown Jewish Center'
    LIMIT 1
  );

-- 11. Adam Zeff at Germantown Jewish Center
UPDATE public.rabbis
SET start_year = 2010,
    end_year = 2010
WHERE name = 'Adam Zeff'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Germantown Jewish Center'
    LIMIT 1
  );

-- 12. Simon Greenberg at Har Zion Temple
UPDATE public.rabbis
SET start_year = 1936,
    end_year = 1936
WHERE name = 'Simon Greenberg'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Har Zion Temple'
    LIMIT 1
  );

-- 13. Abraham A. Levene at Lower Merion Synagogue
UPDATE public.rabbis
SET start_year = 1967,
    end_year = 2006
WHERE name = 'Abraham A. Levene'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Lower Merion Synagogue'
    LIMIT 1
  );

-- 14. Theodore H. Gordon at Main Line Reform Temple
UPDATE public.rabbis
SET start_year = 1961,
    end_year = 1979
WHERE name = 'Theodore H. Gordon'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Main Line Reform Temple'
    LIMIT 1
  );

-- 15. Isaac Moseson at Melrose B'nai Israel- Emanu-el
UPDATE public.rabbis
SET start_year = 1980,
    end_year = 1995
WHERE name = 'Isaac Moseson'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Melrose B''nai Israel- Emanu-el'
    LIMIT 1
  );

-- 16. Yael Levy at Mishkan Shalom
UPDATE public.rabbis
SET start_year = 1996,
    end_year = 2002
WHERE name = 'Yael Levy'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Mishkan Shalom'
    LIMIT 1
  );

-- 17. David Wachtfogel at Ohel Jacob of Oxford Circle
UPDATE public.rabbis
SET start_year = 1961,
    end_year = 1971
WHERE name = 'David Wachtfogel'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Ohel Jacob of Oxford Circle'
    LIMIT 1
  );

-- 18. Seymour Prystowsky at Or Ami. See also, Ivy Ridge Jewish Community Center
UPDATE public.rabbis
SET start_year = 1963,
    end_year = 2000
WHERE name = 'Seymour Prystowsky'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Or Ami. See also, Ivy Ridge Jewish Community Center'
    LIMIT 1
  );

-- 19. Alan Iser at Or Shalom
UPDATE public.rabbis
SET start_year = 1993,
    end_year = 2007
WHERE name = 'Alan Iser'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Or Shalom'
    LIMIT 1
  );

-- 20. Arthur Lavinsky at Beth Tfilla of Overbrook Park
UPDATE public.rabbis
SET start_year = 1982,
    end_year = 1986
WHERE name = 'Arthur Lavinsky'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Tfilla of Overbrook Park'
    LIMIT 1
  );

-- 21. Marcia Prager at Pnai Or Religious Fellowship of Philadelphia-Jewish Renewal
UPDATE public.rabbis
SET start_year = 1994,
    end_year = 2017
WHERE name = 'Marcia Prager'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Pnai Or Religious Fellowship of Philadelphia-Jewish Renewal'
    LIMIT 1
  );

-- 22. Israel M. Axelrod at Raim Ahuvim
UPDATE public.rabbis
SET start_year = 1990,
    end_year = 2004
WHERE name = 'Israel M. Axelrod'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Raim Ahuvim'
    LIMIT 1
  );

-- 23. Sherman Novoseller at Temple Israel
UPDATE public.rabbis
SET start_year = 1950,
    end_year = 1963
WHERE name = 'Sherman Novoseller'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Temple Israel'
    LIMIT 1
  );

-- 24. Sidney Greenberg at Temple Sinai
UPDATE public.rabbis
SET start_year = 1950,
    end_year = 1994
WHERE name = 'Sidney Greenberg'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Temple Sinai'
    LIMIT 1
  );

-- 25. Joshua Kalev at Tiferet Bet Israel
UPDATE public.rabbis
SET start_year = 2008,
    end_year = 2017
WHERE name = 'Joshua Kalev'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Tiferet Bet Israel'
    LIMIT 1
  );

-- 26. William Eisenberg at Tikvoh Chadoshoh
UPDATE public.rabbis
SET start_year = 1981,
    end_year = 1988
WHERE name = 'William Eisenberg'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Tikvoh Chadoshoh'
    LIMIT 1
  );

-- 27. Aileen Hollander at Beth Chaim Reform Congregation
UPDATE public.rabbis
SET start_year = 2002,
    end_year = 2017
WHERE name = 'Aileen Hollander'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Chaim Reform Congregation'
    LIMIT 1
  );

-- 28. Israel Wolmark at Young People's Congregation - Shari Eli.
UPDATE public.rabbis
SET start_year = 1973,
    end_year = 2004
WHERE name = 'Israel Wolmark'
  AND synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Young People''s Congregation - Shari Eli.'
    LIMIT 1
  );

-- ============================================================================
-- SECTION 3: RABBI DATA - NEW ADDITIONS
-- ============================================================================
-- Inserting 431 new rabbi records

-- 1. Martin Berkowitz at Adath Israel of the Main Line (1949-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Martin Berkowitz',
  1949,
  1963,
  true
FROM public.synagogues
WHERE name = 'Adath Israel of the Main Line'
LIMIT 1;

-- 2. Frederic Kazan at Adath Israel (1982-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Frederic Kazan',
  1982,
  2001,
  true
FROM public.synagogues
WHERE name = 'Adath Israel'
LIMIT 1;

-- 3. Steven C. Wernick at Adath Israel (2002-2006.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Steven C. Wernick',
  2002,
  2006,
  true
FROM public.synagogues
WHERE name = 'Adath Israel'
LIMIT 1;

-- 4. Steven C. Wernick at Adath Israel (2008-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Steven C. Wernick',
  2008,
  2008,
  true
FROM public.synagogues
WHERE name = 'Adath Israel'
LIMIT 1;

-- 5. Robert Rubin at Adath Israel (2009-2009.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert Rubin',
  2009,
  2009,
  true
FROM public.synagogues
WHERE name = 'Adath Israel'
LIMIT 1;

-- 6. Eric Yanoff at Adath Israel (2010-2010.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eric Yanoff',
  2010,
  2010,
  true
FROM public.synagogues
WHERE name = 'Adath Israel'
LIMIT 1;

-- 7. Max D. Klein at Adath Jeshurun (1936-1960.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Max D. Klein',
  1936,
  1960,
  true
FROM public.synagogues
WHERE name = 'Adath Jeshurun'
LIMIT 1;

-- 8. Yaakov G. Rosenberg at Adath Jeshurun (1961-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yaakov G. Rosenberg',
  1961,
  1977,
  true
FROM public.synagogues
WHERE name = 'Adath Jeshurun'
LIMIT 1;

-- 9. Leo Ginsburg at Adath Shalom (1961-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Leo Ginsburg',
  1961,
  1961,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 10. Aaron Decter at Adath Shalom (1962-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Decter',
  1962,
  1965,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 11. Aharon Shuman at Adath Shalom (1966-1970.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aharon Shuman',
  1966,
  1970,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 12. Leo Ginsburg at Adath Shalom (1971-1976.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Leo Ginsburg',
  1971,
  1976,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 13. Robert Tabak at Adath Shalom (1978-1978.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert Tabak',
  1978,
  1978,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 14. Lewis J. Eron at Adath Shalom (1979-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Lewis J. Eron',
  1979,
  1980,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 15. Gail Glicksman at Adath Shalom (1981-1985.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gail Glicksman',
  1981,
  1985,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 16. Jon Cutler at Adath Shalom (1986-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jon Cutler',
  1986,
  1986,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 17. Carl S. Choper at Adath Shalom (1987-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Carl S. Choper',
  1987,
  1988,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 18. Brian Goldman at Adath Shalom (1990-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Brian Goldman',
  1990,
  1991,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 19. Felix Freifelder at Ahavath Zion (1950-1951.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Felix Freifelder',
  1950,
  1951,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 20. Meyer Kramer at Ahavath Zion (1952-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Meyer Kramer',
  1952,
  1967,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 21. Sheldon(Simcha) C. Freedman at Ahavath Zion (1968-1974.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sheldon(Simcha) C. Freedman',
  1968,
  1974,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 22. Marvin H. Goldman at Ahavath Zion (1975-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Marvin H. Goldman',
  1975,
  1997,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 23. Dov Chechik at Ahavath Zion (1998-1999.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Dov Chechik',
  1998,
  1999,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 24. Norman Novick at Ahavath Zion (2000-2000.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Norman Novick',
  2000,
  2000,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 25. Arnold Shuman at Ahavath Zion (2001-2005.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Arnold Shuman',
  2001,
  2005,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 26. Steven A. Saks at Ahavath Zion (2006-2007.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Steven A. Saks',
  2006,
  2007,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 27. Isidor Solomon at Ahavath Israel of Kensington. (1961-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Isidor Solomon',
  1961,
  1988,
  true
FROM public.synagogues
WHERE name = 'Ahavath Israel of Kensington.'
LIMIT 1;

-- 28. Abraham Novitsky at Aitz Chaim Synagogue Center (1962-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham Novitsky',
  1962,
  2001,
  true
FROM public.synagogues
WHERE name = 'Aitz Chaim Synagogue Center'
LIMIT 1;

-- 29. Eliezer Ponpko at Aitz Chaim VeZichron Jacob (1961-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eliezer Ponpko',
  1961,
  1961,
  true
FROM public.synagogues
WHERE name = 'Aitz Chaim VeZichron Jacob'
LIMIT 1;

-- 30. M. David Ramaz at Aitz Chaim VeZichron Jacob (1962-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'M. David Ramaz',
  1962,
  1966,
  true
FROM public.synagogues
WHERE name = 'Aitz Chaim VeZichron Jacob'
LIMIT 1;

-- 31. Beryl Berkowitz at Anshe Sholem (1961-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Beryl Berkowitz',
  1961,
  1969,
  true
FROM public.synagogues
WHERE name = 'Anshe Sholem'
LIMIT 1;

-- 32. Baruch Rochmas at Tifereth Israel (1961-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Baruch Rochmas',
  1961,
  1966,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel'
LIMIT 1;

-- 33. Melvin S. Kramer at Tifereth Israel (1967-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Melvin S. Kramer',
  1967,
  1973,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel'
LIMIT 1;

-- 34. Baruch Rochmas at Tifereth Israel (1974-1974.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Baruch Rochmas',
  1974,
  1974,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel'
LIMIT 1;

-- 35. Linda Holtzman at Beth Ahavah (1985-1989.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Linda Holtzman',
  1985,
  1989,
  true
FROM public.synagogues
WHERE name = 'Beth Ahavah'
LIMIT 1;

-- 36. Jacob Chinitz at Jewish Congregation of (1961-1978.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jacob Chinitz',
  1961,
  1978,
  true
FROM public.synagogues
WHERE name = 'Jewish Congregation of'
LIMIT 1;

-- 37. Joseph Teichman at Beth Ami (1979-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph Teichman',
  1979,
  1980,
  true
FROM public.synagogues
WHERE name = 'Beth Ami'
LIMIT 1;

-- 38. Joseph Rothstein at Beth Ami (1981-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph Rothstein',
  1981,
  1984,
  true
FROM public.synagogues
WHERE name = 'Beth Ami'
LIMIT 1;

-- 39. David Novitsky at Beth Ami (1986-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Novitsky',
  1986,
  1988,
  true
FROM public.synagogues
WHERE name = 'Beth Ami'
LIMIT 1;

-- 40. Aaron Griver at Beth Ami (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Griver',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth Ami'
LIMIT 1;

-- 41. Morris S. Goodblatt at Beth Am Israel (1936-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Morris S. Goodblatt',
  1936,
  1966,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 42. Eugene A. Wernick at Beth Am Israel (1968-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eugene A. Wernick',
  1968,
  1968,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 43. Efry Spectre at Beth Am Israel (1969-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Efry Spectre',
  1969,
  1969,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 44. Lawrence H. Geiger at Beth Am Israel (1972-1972.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Lawrence H. Geiger',
  1972,
  1972,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 45. Alan Turetz at Beth Am Israel (1973-1975.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Alan Turetz',
  1973,
  1975,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 46. Norman Saul Goldman at Beth Am Israel (1977-1979.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Norman Saul Goldman',
  1977,
  1979,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 47. Andrew M. Sacks at Beth Am Israel (1980-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Andrew M. Sacks',
  1980,
  1984,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 48. Sheila P. Weinberg at Beth Am Israel (1986-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sheila P. Weinberg',
  1986,
  1988,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 49. Marc Joel Margolius at Beth Am Israel (1989-2002.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Marc Joel Margolius',
  1989,
  2002,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 50. David Ackerman at Beth Am Israel (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Ackerman',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 51. Gerald R. Fox at Beth Chaim (2004-2005.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gerald R. Fox',
  2004,
  2005,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim'
LIMIT 1;

-- 52. Samuel H. Markowitz at Beth Chaim Reform Congregation (1952-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Samuel H. Markowitz',
  1952,
  1963,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 53. Henry Cohen at Beth Chaim Reform Congregation (1964-1992.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Henry Cohen',
  1964,
  1992,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 54. Robert L. Rozenberg at Beth Chaim Reform Congregation (1993-1998.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert L. Rozenberg',
  1993,
  1998,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 55. Andrew J. Busch at Beth Chaim Reform Congregation (1999-2004.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Andrew J. Busch',
  1999,
  2004,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 56. Jim Egolf at Beth Chaim Reform Congregation (2005-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jim Egolf',
  2005,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 57. Samuel Fredman at Beth El (1936-1936.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Samuel Fredman',
  1936,
  1936,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 58. Leon S. Lang at Beth El (1950-1956.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Leon S. Lang',
  1950,
  1956,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 59. Marshall J. Maltzman at Beth El (1957-1960.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Marshall J. Maltzman',
  1957,
  1960,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 60. Lewis B. Grossman at Beth El (1961-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Lewis B. Grossman',
  1961,
  1969,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 61. Simeon Kabrinetz at Beth El, Suburban (1961-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Simeon Kabrinetz',
  1961,
  1962,
  true
FROM public.synagogues
WHERE name = 'Beth El, Suburban'
LIMIT 1;

-- 62. Menachem Raab at Beth Emeth. (1952-1953.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Menachem Raab',
  1952,
  1953,
  true
FROM public.synagogues
WHERE name = 'Beth Emeth.'
LIMIT 1;

-- 63. Isadore Tannenburg at Beth HaMedrosh Hagodol-Beth Yaacov (1974-1974.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Isadore Tannenburg',
  1974,
  1974,
  true
FROM public.synagogues
WHERE name = 'Beth HaMedrosh Hagodol-Beth Yaacov'
LIMIT 1;

-- 64. Chaim Zav Budnick at Beth HaMedrosh Hagodol-Beth Yaacov (1986-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Chaim Zav Budnick',
  1986,
  1991,
  true
FROM public.synagogues
WHERE name = 'Beth HaMedrosh Hagodol-Beth Yaacov'
LIMIT 1;

-- 65. Yonah Gross at Beth HaMedrash (2010-2010.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yonah Gross',
  2010,
  2010,
  true
FROM public.synagogues
WHERE name = 'Beth HaMedrash'
LIMIT 1;

-- 66. Meyer Finklestein at Beth Israel (1950-1951.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Meyer Finklestein',
  1950,
  1951,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 67. Samuel Perver at Beth Israel (1952-1954.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Samuel Perver',
  1952,
  1954,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 68. Mordecai L. Brill at Beth Israel (1955-1957.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mordecai L. Brill',
  1955,
  1957,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 69. Solomon Herbst at Beth Israel (1960-1960.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Solomon Herbst',
  1960,
  1960,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 70. Matthew S. Rosen at Beth Israel (1961-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Matthew S. Rosen',
  1961,
  1961,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 71. Gershon Winer at Beth Israel (1962-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gershon Winer',
  1962,
  1962,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 72. Michael I. Charney at Brith Israel Congregation (1988-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Michael I. Charney',
  1988,
  2017,
  true
FROM public.synagogues
WHERE name = 'Brith Israel Congregation'
LIMIT 1;

-- 73. Alex Pollack at Beth Israel (1970-1975.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Alex Pollack',
  1970,
  1975,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 74. Louis Zivic at Beth Israel (1976-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis Zivic',
  1976,
  1980,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 75. Jacob Rosner at Beth Israel (1981-1981.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jacob Rosner',
  1981,
  1981,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 76. Robert Dobrusin at Beth Israel (1982-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert Dobrusin',
  1982,
  1987,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 77. Herbert Rosenblum at Beth Israel (1988-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Herbert Rosenblum',
  1988,
  1988,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 78. Louis Leifer at Beth Judah (1956-1960.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis Leifer',
  1956,
  1960,
  true
FROM public.synagogues
WHERE name = 'Beth Judah'
LIMIT 1;

-- 79. Solomon Shoulson at Beth Jacob of West Philadelphia [Chevra] (1961-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Solomon Shoulson',
  1961,
  1962,
  true
FROM public.synagogues
WHERE name = 'Beth Jacob of West Philadelphia [Chevra]'
LIMIT 1;

-- 80. Stanley Berkovitch at Beth Jacob of West Philadelphia [Chevra] (1963-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Stanley Berkovitch',
  1963,
  1964,
  true
FROM public.synagogues
WHERE name = 'Beth Jacob of West Philadelphia [Chevra]'
LIMIT 1;

-- 81. Saul Israel Wisemon at Beth Jacob of West Philadelphia [Chevra] (1965-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Saul Israel Wisemon',
  1965,
  1965,
  true
FROM public.synagogues
WHERE name = 'Beth Jacob of West Philadelphia [Chevra]'
LIMIT 1;

-- 82. Theodore Sanders at Beth Jacob of West Philadelphia [Chevra] (1966-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Theodore Sanders',
  1966,
  1967,
  true
FROM public.synagogues
WHERE name = 'Beth Jacob of West Philadelphia [Chevra]'
LIMIT 1;

-- 83. Yosef Geldzahler at Beth HaMedrash Hare (2008-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yosef Geldzahler',
  2008,
  2008,
  true
FROM public.synagogues
WHERE name = 'Beth HaMedrash Hare'
LIMIT 1;

-- 84. Meyer Isaacson at Beth Solomon (1961-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Meyer Isaacson',
  1961,
  1965,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 85. Aaron Landes at Dorshe Sholom Congregation (1964-1999.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Landes',
  1964,
  1999,
  true
FROM public.synagogues
WHERE name = 'Dorshe Sholom Congregation'
LIMIT 1;

-- 86. Gershon Schwartz at Dorshe Sholom Congregation (2000-2002.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gershon Schwartz',
  2000,
  2002,
  true
FROM public.synagogues
WHERE name = 'Dorshe Sholom Congregation'
LIMIT 1;

-- 87. David Glanzberg-Krainin at Dorshe Sholom Congregation (2004-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Glanzberg-Krainin',
  2004,
  2017,
  true
FROM public.synagogues
WHERE name = 'Dorshe Sholom Congregation'
LIMIT 1;

-- 88. Meyer Isaacson at Beth Solomon (1961-1975.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Meyer Isaacson',
  1961,
  1975,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 89. Solomon Isaacson at Beth El, Suburban (1972-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Solomon Isaacson',
  1972,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth El, Suburban'
LIMIT 1;

-- 90. Alexander M. Shapiro at Beth Tikvah (1961-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Alexander M. Shapiro',
  1961,
  1968,
  true
FROM public.synagogues
WHERE name = 'Beth Tikvah'
LIMIT 1;

-- 91. Amiel Novoseller at Beth Tovim (1982-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Amiel Novoseller',
  1982,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth Tovim'
LIMIT 1;

-- 92. Ralph M. Weisberger at Beth Uziel (1956-1958.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Ralph M. Weisberger',
  1956,
  1958,
  true
FROM public.synagogues
WHERE name = 'Beth Uziel'
LIMIT 1;

-- 93. Jerome Chervin at Beth Uziel (1959-1959.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jerome Chervin',
  1959,
  1959,
  true
FROM public.synagogues
WHERE name = 'Beth Uziel'
LIMIT 1;

-- 94. Isadore Barnett at Beth Uziel (1960-1970.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Isadore Barnett',
  1960,
  1970,
  true
FROM public.synagogues
WHERE name = 'Beth Uziel'
LIMIT 1;

-- 95. David Schectman at Beth Uziel (1972-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Schectman',
  1972,
  1980,
  true
FROM public.synagogues
WHERE name = 'Beth Uziel'
LIMIT 1;

-- 96. Manuel Armon at Beth Uziel (1982-1982.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Manuel Armon',
  1982,
  1982,
  true
FROM public.synagogues
WHERE name = 'Beth Uziel'
LIMIT 1;

-- 97. Oscar Kramer at Beth Uziel (1983-1994.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Oscar Kramer',
  1983,
  1994,
  true
FROM public.synagogues
WHERE name = 'Beth Uziel'
LIMIT 1;

-- 98. Yaakov Rosenberg at Har Zion Temple (1949-1954.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yaakov Rosenberg',
  1949,
  1954,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 99. Reuben J. Magil at Beth Zion-Beth Israel [Temple] (1955-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Reuben J. Magil',
  1955,
  1983,
  true
FROM public.synagogues
WHERE name = 'Beth Zion-Beth Israel [Temple]'
LIMIT 1;

-- 100. David Wolf Silverman at Beth Zion-Beth Israel [Temple] (1984-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Wolf Silverman',
  1984,
  1987,
  true
FROM public.synagogues
WHERE name = 'Beth Zion-Beth Israel [Temple]'
LIMIT 1;

-- 101. Ira F. Stone at Beth Zion-Beth Israel [Temple] (1988-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Ira F. Stone',
  1988,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth Zion-Beth Israel [Temple]'
LIMIT 1;

-- 102. Matthew S. Rosen at B'nai Aaron (1936-1936.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Matthew S. Rosen',
  1936,
  1936,
  true
FROM public.synagogues
WHERE name = 'B''nai Aaron'
LIMIT 1;

-- 103. Shraga Sherman at B'nai Abraham (1993-1999.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Shraga Sherman',
  1993,
  1999,
  true
FROM public.synagogues
WHERE name = 'B''nai Abraham'
LIMIT 1;

-- 104. Yochonon Goldman at B'nai Abraham (2000-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yochonon Goldman',
  2000,
  2017,
  true
FROM public.synagogues
WHERE name = 'B''nai Abraham'
LIMIT 1;

-- 105. Maier Fuchs, Abraham Fuchs at B'nai Abraham Jewish Center (1962-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Maier Fuchs, Abraham Fuchs',
  1962,
  1986,
  true
FROM public.synagogues
WHERE name = 'B''nai Abraham Jewish Center'
LIMIT 1;

-- 106. Moses J. Burak at B'nai Israel of Olney (1955-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Moses J. Burak',
  1955,
  1961,
  true
FROM public.synagogues
WHERE name = 'B''nai Israel of Olney'
LIMIT 1;

-- 107. Isadore Budick at B'nai Israel of Olney (1949-1953.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Isadore Budick',
  1949,
  1953,
  true
FROM public.synagogues
WHERE name = 'B''nai Israel of Olney'
LIMIT 1;

-- 108. Bernard D. Perlow at B'nai Israel of Olney (1954-1954.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Bernard D. Perlow',
  1954,
  1954,
  true
FROM public.synagogues
WHERE name = 'B''nai Israel of Olney'
LIMIT 1;

-- 109. Moses J. Burak at B'nai Israel of Olney (1956-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Moses J. Burak',
  1956,
  1961,
  true
FROM public.synagogues
WHERE name = 'B''nai Israel of Olney'
LIMIT 1;

-- 110. Bruce Harbater at B'nai Jacob (1966-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Bruce Harbater',
  1966,
  1966,
  true
FROM public.synagogues
WHERE name = 'B''nai Jacob'
LIMIT 1;

-- 111. Baruch Leizerowski at B'nai Jacob (1961-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Baruch Leizerowski',
  1961,
  1991,
  true
FROM public.synagogues
WHERE name = 'B''nai Jacob'
LIMIT 1;

-- 112. Morris Pickholz at B'nai Jeshurun Ahavas Chesed (1950-1970.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Morris Pickholz',
  1950,
  1970,
  true
FROM public.synagogues
WHERE name = 'B''nai Jeshurun Ahavas Chesed'
LIMIT 1;

-- 113. Bruce E. Harber at B'nai Jeshurun of Mount Airy. (1971-1972.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Bruce E. Harber',
  1971,
  1972,
  true
FROM public.synagogues
WHERE name = 'B''nai Jeshurun of Mount Airy.'
LIMIT 1;

-- 114. David S. Novoseller at B'nai Joshua (1961-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David S. Novoseller',
  1961,
  1965,
  true
FROM public.synagogues
WHERE name = 'B''nai Joshua'
LIMIT 1;

-- 115. Harold Novoseller at B'nai Joshua (1966-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harold Novoseller',
  1966,
  1973,
  true
FROM public.synagogues
WHERE name = 'B''nai Joshua'
LIMIT 1;

-- 116. David Kapustin at B'nai Moishe (1962-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Kapustin',
  1962,
  1963,
  true
FROM public.synagogues
WHERE name = 'B''nai Moishe'
LIMIT 1;

-- 117. Gerald Solomon at B'nai Torah (1970-1970.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gerald Solomon',
  1970,
  1970,
  true
FROM public.synagogues
WHERE name = 'B''nai Torah'
LIMIT 1;

-- 118. Abraham Margolis at B'nai Sholom (1960-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham Margolis',
  1960,
  1961,
  true
FROM public.synagogues
WHERE name = 'B''nai Sholom'
LIMIT 1;

-- 119. M. L. Barg at B'nai Sholom (1962-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'M. L. Barg',
  1962,
  1963,
  true
FROM public.synagogues
WHERE name = 'B''nai Sholom'
LIMIT 1;

-- 120. Sheldon C. Freedman at Ahavas Torah Congregation (1964-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sheldon C. Freedman',
  1964,
  1967,
  true
FROM public.synagogues
WHERE name = 'Ahavas Torah Congregation'
LIMIT 1;

-- 121. C. Joseph Teichman at Ahavas Torah Congregation (1968-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'C. Joseph Teichman',
  1968,
  1968,
  true
FROM public.synagogues
WHERE name = 'Ahavas Torah Congregation'
LIMIT 1;

-- 122. Gerald Lerer at Ahavas Torah Congregation (1969-1970.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gerald Lerer',
  1969,
  1970,
  true
FROM public.synagogues
WHERE name = 'Ahavas Torah Congregation'
LIMIT 1;

-- 123. Aharon Shuman at Ahavas Torah Congregation (1971-1971.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aharon Shuman',
  1971,
  1971,
  true
FROM public.synagogues
WHERE name = 'Ahavas Torah Congregation'
LIMIT 1;

-- 124. Seymour Panitz at Ahavas Torah Congregation (1972-1976.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Seymour Panitz',
  1972,
  1976,
  true
FROM public.synagogues
WHERE name = 'Ahavas Torah Congregation'
LIMIT 1;

-- 125. Arnold H. Feldman at B'nai Yitzchok (1961-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Arnold H. Feldman',
  1961,
  1962,
  true
FROM public.synagogues
WHERE name = 'B''nai Yitzchok'
LIMIT 1;

-- 126. C. Joseph Teichman at B'nai Yitzchok (1963-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'C. Joseph Teichman',
  1963,
  1964,
  true
FROM public.synagogues
WHERE name = 'B''nai Yitzchok'
LIMIT 1;

-- 127. Saul I. Aranov at B'nai Yitzchok (1965-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Saul I. Aranov',
  1965,
  1968,
  true
FROM public.synagogues
WHERE name = 'B''nai Yitzchok'
LIMIT 1;

-- 128. Sholem J. Horowitz at B'nai Yitzchok (1970-1982.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sholem J. Horowitz',
  1970,
  1982,
  true
FROM public.synagogues
WHERE name = 'B''nai Yitzchok'
LIMIT 1;

-- 129. Leonard Guttman at B'nai Yitzchok (1983-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Leonard Guttman',
  1983,
  1983,
  true
FROM public.synagogues
WHERE name = 'B''nai Yitzchok'
LIMIT 1;

-- 130. David Novitsky at B'nai Yitzchok (1984-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Novitsky',
  1984,
  1984,
  true
FROM public.synagogues
WHERE name = 'B''nai Yitzchok'
LIMIT 1;

-- 131. Arnold Shuman at B'nai Yitzchok (1985-1985.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Arnold Shuman',
  1985,
  1985,
  true
FROM public.synagogues
WHERE name = 'B''nai Yitzchok'
LIMIT 1;

-- 132. Nachum M. Waldman at Bristol Jewish Center (1971-1974.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Nachum M. Waldman',
  1971,
  1974,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 133. Jacob Staub at Bristol Jewish Center (1976-1978.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jacob Staub',
  1976,
  1978,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 134. Todd Silverberg at Bristol Jewish Center (1979-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Todd Silverberg',
  1979,
  1980,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 135. Barry Blum at Bristol Jewish Center (1981-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Barry Blum',
  1981,
  1983,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 136. Sue Levy at Bristol Jewish Center (1984-1985.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sue Levy',
  1984,
  1985,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 137. Robert J. Gluck at Bristol Jewish Center (1986-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert J. Gluck',
  1986,
  1986,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 138. David E. Stein at Bristol Jewish Center (1987-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David E. Stein',
  1987,
  1988,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 139. Margaret Jacob, Ruth Ehrenstein at Bristol Jewish Center (1990-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Margaret Jacob, Ruth Ehrenstein',
  1990,
  1991,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 140. Rebecca Lillian, Meryl Steinman at Bristol Jewish Center (1992-1992.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Rebecca Lillian, Meryl Steinman',
  1992,
  1992,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 141. Meryl Steinman at Bristol Jewish Center (1993-1993.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Meryl Steinman',
  1993,
  1993,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 142. Joseph M. Blair, Kevin Hale, Mark Zarkh at Bristol Jewish Center (1994-1994.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph M. Blair, Kevin Hale, Mark Zarkh',
  1994,
  1994,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 143. Kevin Hale, Mark Zarkh at Bristol Jewish Center (1995-1995.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Kevin Hale, Mark Zarkh',
  1995,
  1995,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 144. Jonathan Cohen, Kevin Hale at Bristol Jewish Center (1996-1996.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jonathan Cohen, Kevin Hale',
  1996,
  1996,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 145. Jonathan Cohen, Aileen Hollander at Bristol Jewish Center (1997-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jonathan Cohen, Aileen Hollander',
  1997,
  1997,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 146. Aileen Hollander, Murray Silberman at Bristol Jewish Center (1998-1998.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aileen Hollander, Murray Silberman',
  1998,
  1998,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 147. Aileen Hollander, Murray Silberman, Gabrielle Kaplan at Bristol Jewish Center (1999-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aileen Hollander, Murray Silberman, Gabrielle Kaplan',
  1999,
  2001,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 148. Judith Abrahamson at Bristol Jewish Center (2002-2003.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Judith Abrahamson',
  2002,
  2003,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 149. Heidi Waldman at Bristol Jewish Center (2004-2004.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Heidi Waldman',
  2004,
  2004,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 150. Sandra Rubenstein at Bristol Jewish Center (2005-2005.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sandra Rubenstein',
  2005,
  2005,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 151. Amanda Lurer at Bristol Jewish Center (2006-2006.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Amanda Lurer',
  2006,
  2006,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 152. Abraham J. Levy at Beth Israel (1936-1960.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham J. Levy',
  1936,
  1960,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 153. Tobias Rothenberg at Beth Israel (1961-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Tobias Rothenberg',
  1961,
  1968,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 154. Eugene A. Wernick at Beth Israel (1970-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eugene A. Wernick',
  1970,
  1973,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 155. William Greenberg at Beth Israel (1975-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'William Greenberg',
  1975,
  1986,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 156. Arnold Shuman at Beth Israel (1987-1989.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Arnold Shuman',
  1987,
  1989,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 157. Gary Gerson at Brotherhood Temple Achim (1975-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gary Gerson',
  1975,
  1977,
  true
FROM public.synagogues
WHERE name = 'Brotherhood Temple Achim'
LIMIT 1;

-- 158. Hava Pell at Brith Achim (1979-1982.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Hava Pell',
  1979,
  1982,
  true
FROM public.synagogues
WHERE name = 'Brith Achim'
LIMIT 1;

-- 159. David Cahn-Lipman at Brith Achim (1983-1985.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Cahn-Lipman',
  1983,
  1985,
  true
FROM public.synagogues
WHERE name = 'Brith Achim'
LIMIT 1;

-- 160. Robert Ourach at Brith Achim (1986-2002.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert Ourach',
  1986,
  2002,
  true
FROM public.synagogues
WHERE name = 'Brith Achim'
LIMIT 1;

-- 161. Eric J. Lazar at Brith Achim (2004-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eric J. Lazar',
  2004,
  2017,
  true
FROM public.synagogues
WHERE name = 'Brith Achim'
LIMIT 1;

-- 162. Ira S. Youdovin at Shir Ami-Bucks County Jewish Congregation (1977-1978.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Ira S. Youdovin',
  1977,
  1978,
  true
FROM public.synagogues
WHERE name = 'Shir Ami-Bucks County Jewish Congregation'
LIMIT 1;

-- 163. Bertram A. Leff at Ner Tamid of Delaware County (1962-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Bertram A. Leff',
  1962,
  1965,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 164. Saul I. Wisemon at Ner Tamid of Delaware County (1966-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Saul I. Wisemon',
  1966,
  1967,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 165. Keneth M. Tarlow at Ner Tamid of Delaware County (1968-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Keneth M. Tarlow',
  1968,
  1969,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 166. Baruch P. Schectman at Ner Tamid of Delaware County (1970-1975.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Baruch P. Schectman',
  1970,
  1975,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 167. Aaron Kriegel at Ner Tamid of Delaware County (1976-1978.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Kriegel',
  1976,
  1978,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 168. Lee Friedlander at Ner Tamid of Delaware County (1979-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Lee Friedlander',
  1979,
  1980,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 169. Joseph Teichman at Ner Tamid of Delaware County (1981-1982.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph Teichman',
  1981,
  1982,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 170. Richard Libowitz at Ner Tamid of Delaware County (1983-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Richard Libowitz',
  1983,
  1991,
  true
FROM public.synagogues
WHERE name = 'Ner Tamid of Delaware County'
LIMIT 1;

-- 171. Alexander E. Levin at East Lane Temple (1961-1992.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Alexander E. Levin',
  1961,
  1992,
  true
FROM public.synagogues
WHERE name = 'East Lane Temple'
LIMIT 1;

-- 172. Harold Liebowitz at Ezrath Israel (1964-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harold Liebowitz',
  1964,
  1964,
  true
FROM public.synagogues
WHERE name = 'Ezrath Israel'
LIMIT 1;

-- 173. Sender Shizgal at Ezrath Israel (1965-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sender Shizgal',
  1965,
  1965,
  true
FROM public.synagogues
WHERE name = 'Ezrath Israel'
LIMIT 1;

-- 174. Abraham Pelberg at Ezrath Israel (1966-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham Pelberg',
  1966,
  1967,
  true
FROM public.synagogues
WHERE name = 'Ezrath Israel'
LIMIT 1;

-- 175. Murray Moses Goldman at Ezrath Israel (1968-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Murray Moses Goldman',
  1968,
  1968,
  true
FROM public.synagogues
WHERE name = 'Ezrath Israel'
LIMIT 1;

-- 176. L. Vegh at Greater Northeast Congregation (1983-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'L. Vegh',
  1983,
  1983,
  true
FROM public.synagogues
WHERE name = 'Greater Northeast Congregation'
LIMIT 1;

-- 177. Dov A.Brisman at Greater Northeast Congregation (1984-1985.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Dov A.Brisman',
  1984,
  1985,
  true
FROM public.synagogues
WHERE name = 'Greater Northeast Congregation'
LIMIT 1;

-- 178. Boris Cahan at Fox Chase Jewish Community Center (1961-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Boris Cahan',
  1961,
  1965,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 179. Oscar Kramer at Fox Chase Jewish Community Center (1966-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Oscar Kramer',
  1966,
  1973,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 180. Theodore Sanders at Fox Chase Jewish Community Center (1974-1976.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Theodore Sanders',
  1974,
  1976,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 181. Arnold Shuman at Fox Chase Jewish Community Center (1978-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Arnold Shuman',
  1978,
  1984,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 182. Elias Charry at Germantown Jewish Center (1949-1972.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Elias Charry',
  1949,
  1972,
  true
FROM public.synagogues
WHERE name = 'Germantown Jewish Center'
LIMIT 1;

-- 183. Cliffird B. Miller at Germantown Jewish Center (1973-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Cliffird B. Miller',
  1973,
  1973,
  true
FROM public.synagogues
WHERE name = 'Germantown Jewish Center'
LIMIT 1;

-- 184. M. David Weiss at Germantown Jewish Center (1974-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'M. David Weiss',
  1974,
  1977,
  true
FROM public.synagogues
WHERE name = 'Germantown Jewish Center'
LIMIT 1;

-- 185. Leonard D. Gordon at Germantown Jewish Center (1994-2009.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Leonard D. Gordon',
  1994,
  2009,
  true
FROM public.synagogues
WHERE name = 'Germantown Jewish Center'
LIMIT 1;

-- 186. David A. Goldstein; Herman E. Grossman at Har Zion Temple (1949-1949.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David A. Goldstein; Herman E. Grossman',
  1949,
  1949,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 187. David A. Goldstein at Har Zion Temple (1950-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David A. Goldstein',
  1950,
  1968,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 188. Gerald I. Wolpe at Har Zion Temple (1969-1998.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gerald I. Wolpe',
  1969,
  1998,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 189. Jacob Herber at Har Zion Temple (1999-2002.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jacob Herber',
  1999,
  2002,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 190. Jay M. Stein at Har Zion Temple (2003-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jay M. Stein',
  2003,
  2017,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 191. Kenneth M. Tarlow at Har Zion Temple (1970-1971.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Kenneth M. Tarlow',
  1970,
  1971,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 192. Gary Charlestein at Har Zion Temple (1972-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gary Charlestein',
  1972,
  1973,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 193. Robert T. Tabak at Kehilat Chaverim (1997-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert T. Tabak',
  1997,
  1997,
  true
FROM public.synagogues
WHERE name = 'Kehilat Chaverim'
LIMIT 1;

-- 194. Sandy Roth Parian at Kehilat HaNahar Also, [The] Little Shul by the River (1997-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sandy Roth Parian',
  1997,
  2017,
  true
FROM public.synagogues
WHERE name = 'Kehilat HaNahar Also, [The] Little Shul by the River'
LIMIT 1;

-- 195. Sandra Rosenthal Berliner at Kneseth Chai (1983-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sandra Rosenthal Berliner',
  1983,
  1983,
  true
FROM public.synagogues
WHERE name = 'Kneseth Chai'
LIMIT 1;

-- 196. Craig Harris at Kneseth Chai (1984-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Craig Harris',
  1984,
  1984,
  true
FROM public.synagogues
WHERE name = 'Kneseth Chai'
LIMIT 1;

-- 197. Lewis John Eron at Kneseth Chai (1985-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Lewis John Eron',
  1985,
  1986,
  true
FROM public.synagogues
WHERE name = 'Kneseth Chai'
LIMIT 1;

-- 198. William H. Fineshriber at Keneseth Israel (1950-1951.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'William H. Fineshriber',
  1950,
  1951,
  true
FROM public.synagogues
WHERE name = 'Keneseth Israel'
LIMIT 1;

-- 199. Burton Mindick at Kesher Israel Congregation (1964-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Burton Mindick',
  1964,
  1965,
  true
FROM public.synagogues
WHERE name = 'Kesher Israel Congregation'
LIMIT 1;

-- 200. Murray Goldman at Kesher Israel Congregation (1966-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Murray Goldman',
  1966,
  1967,
  true
FROM public.synagogues
WHERE name = 'Kesher Israel Congregation'
LIMIT 1;

-- 201. Irving Rubin at Kesher Israel Congregation (1968-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Irving Rubin',
  1968,
  1977,
  true
FROM public.synagogues
WHERE name = 'Kesher Israel Congregation'
LIMIT 1;

-- 202. Mac Portal at Kesher Israel Congregation (1978-1993.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mac Portal',
  1978,
  1993,
  true
FROM public.synagogues
WHERE name = 'Kesher Israel Congregation'
LIMIT 1;

-- 203. David Glanzberg-Krainin at Kesher Israel Congregation (1994-2003.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Glanzberg-Krainin',
  1994,
  2003,
  true
FROM public.synagogues
WHERE name = 'Kesher Israel Congregation'
LIMIT 1;

-- 204. Eric Rosin at Kesher Israel Congregation (2004-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eric Rosin',
  2004,
  2017,
  true
FROM public.synagogues
WHERE name = 'Kesher Israel Congregation'
LIMIT 1;

-- 205. Sidney Lewis at Keneseth Israel (1982-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sidney Lewis',
  1982,
  1991,
  true
FROM public.synagogues
WHERE name = 'Keneseth Israel'
LIMIT 1;

-- 206. Tsvi Kilstein at Kneses HaSefer- Educational Synagogue of Yardley (1989-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Tsvi Kilstein',
  1989,
  1991,
  true
FROM public.synagogues
WHERE name = 'Kneses HaSefer- Educational Synagogue of Yardley'
LIMIT 1;

-- 207. Shlomo D. Lax at Kneses HaSefer- Educational Synagogue of Yardley (1992-1993.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Shlomo D. Lax',
  1992,
  1993,
  true
FROM public.synagogues
WHERE name = 'Kneses HaSefer- Educational Synagogue of Yardley'
LIMIT 1;

-- 208. Yitzchok Feldheim at Kneses HaSefer- Educational Synagogue of Yardley (1994-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yitzchok Feldheim',
  1994,
  2008,
  true
FROM public.synagogues
WHERE name = 'Kneses HaSefer- Educational Synagogue of Yardley'
LIMIT 1;

-- 209. Dov Halpern at Kneses HaSefer- Educational Synagogue of Yardley (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Dov Halpern',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Kneses HaSefer- Educational Synagogue of Yardley'
LIMIT 1;

-- 210. Elliot J. Holin at Kol Ami (1994-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Elliot J. Holin',
  1994,
  2017,
  true
FROM public.synagogues
WHERE name = 'Kol Ami'
LIMIT 1;

-- 211. David Lev at Kol Emet (1986-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Lev',
  1986,
  1986,
  true
FROM public.synagogues
WHERE name = 'Kol Emet'
LIMIT 1;

-- 212. Ethan Weiner-Kaplow at Kol Emet (1988-1990.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Ethan Weiner-Kaplow',
  1988,
  1990,
  true
FROM public.synagogues
WHERE name = 'Kol Emet'
LIMIT 1;

-- 213. Caryn Broitman at Kol Emet (1991-1995.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Caryn Broitman',
  1991,
  1995,
  true
FROM public.synagogues
WHERE name = 'Kol Emet'
LIMIT 1;

-- 214. Howard K. Cove at Kol Emet (1996-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Howard K. Cove',
  1996,
  2017,
  true
FROM public.synagogues
WHERE name = 'Kol Emet'
LIMIT 1;

-- 215. David Wachtfogel at Lenas HaZedek (1959-1960.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Wachtfogel',
  1959,
  1960,
  true
FROM public.synagogues
WHERE name = 'Lenas HaZedek'
LIMIT 1;

-- 216. G. Rayzel Raphael at Center City Reconstructionist Synagogue (1993-2000.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'G. Rayzel Raphael',
  1993,
  2000,
  true
FROM public.synagogues
WHERE name = 'Center City Reconstructionist Synagogue'
LIMIT 1;

-- 217. Aaron Rothkoff at Lower Merion Synagogue (1961-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Rothkoff',
  1961,
  1961,
  true
FROM public.synagogues
WHERE name = 'Lower Merion Synagogue'
LIMIT 1;

-- 218. Eli M. Lazar at Lower Merion Synagogue (1964-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eli M. Lazar',
  1964,
  1965,
  true
FROM public.synagogues
WHERE name = 'Lower Merion Synagogue'
LIMIT 1;

-- 219. Avraham J. Shmidman at Lower Merion Synagogue (2007-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Avraham J. Shmidman',
  2007,
  2017,
  true
FROM public.synagogues
WHERE name = 'Lower Merion Synagogue'
LIMIT 1;

-- 220. Joseph M. Reich at Melrose B'nai Israel- Emanu-el (1961-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph M. Reich',
  1961,
  1962,
  true
FROM public.synagogues
WHERE name = 'Melrose B''nai Israel- Emanu-el'
LIMIT 1;

-- 221. Fredric Kazan at Melrose B'nai Israel- Emanu-el (1963-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Fredric Kazan',
  1963,
  1968,
  true
FROM public.synagogues
WHERE name = 'Melrose B''nai Israel- Emanu-el'
LIMIT 1;

-- 222. Samuel April at Melrose B'nai Israel- Emanu-el (1969-1978.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Samuel April',
  1969,
  1978,
  true
FROM public.synagogues
WHERE name = 'Melrose B''nai Israel- Emanu-el'
LIMIT 1;

-- 223. Sanford D. Shanblatt at Melrose B'nai Israel- Emanu-el (1996-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sanford D. Shanblatt',
  1996,
  1997,
  true
FROM public.synagogues
WHERE name = 'Melrose B''nai Israel- Emanu-el'
LIMIT 1;

-- 224. Jerry S. Lauterbach at Melrose B'nai Israel- Emanu-el (1999-2004.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jerry S. Lauterbach',
  1999,
  2004,
  true
FROM public.synagogues
WHERE name = 'Melrose B''nai Israel- Emanu-el'
LIMIT 1;

-- 225. Howard A. Addison at Melrose B'nai Israel- Emanu-el (2005-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Howard A. Addison',
  2005,
  2017,
  true
FROM public.synagogues
WHERE name = 'Melrose B''nai Israel- Emanu-el'
LIMIT 1;

-- 226. D. A. J. Cardozo at Mikveh Israel (1949-1951.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'D. A. J. Cardozo',
  1949,
  1951,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 227. Emanuel L. Lifshutz at Mikveh Israel (1952-1954.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Emanuel L. Lifshutz',
  1952,
  1954,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 228. Alan D. Corre at Mikveh Israel (1955-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Alan D. Corre',
  1955,
  1963,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 229. Ezekiel Nissim Musleah at Mikveh Israel (1964-1978.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Ezekiel Nissim Musleah',
  1964,
  1978,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 230. Joshua Toledano at Mikveh Israel (1980-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joshua Toledano',
  1980,
  1987,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 231. Albert E. Gabbai at Mikveh Israel (1988-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Albert E. Gabbai',
  1988,
  1988,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 232. Allan Lazaroff at Mikveh Israel (1989-1990.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Allan Lazaroff',
  1989,
  1990,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 233. Albert E. Gabbai at Mikveh Israel (1992-2009.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Albert E. Gabbai',
  1992,
  2009,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 234. Brian Walt at Mishkan Shalom (1988-1995.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Brian Walt',
  1988,
  1995,
  true
FROM public.synagogues
WHERE name = 'Mishkan Shalom'
LIMIT 1;

-- 235. Jeff Sultar, Yael Levy at Mishkan Shalom (2004-2006.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jeff Sultar, Yael Levy',
  2004,
  2006,
  true
FROM public.synagogues
WHERE name = 'Mishkan Shalom'
LIMIT 1;

-- 236. Linda Holtzman, Yael Levy at Mishkan Shalom (2007-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Linda Holtzman, Yael Levy',
  2007,
  2017,
  true
FROM public.synagogues
WHERE name = 'Mishkan Shalom'
LIMIT 1;

-- 237. Eli B. Greenwald at Israel Congregation (1961-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eli B. Greenwald',
  1961,
  1962,
  true
FROM public.synagogues
WHERE name = 'Israel Congregation'
LIMIT 1;

-- 238. Daniel Mehlman at Israel Congregation (1963-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Daniel Mehlman',
  1963,
  1963,
  true
FROM public.synagogues
WHERE name = 'Israel Congregation'
LIMIT 1;

-- 239. Simha H. Gordon at Israel Congregation (1964-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Simha H. Gordon',
  1964,
  1964,
  true
FROM public.synagogues
WHERE name = 'Israel Congregation'
LIMIT 1;

-- 240. David Silver at Israel Congregation (1965-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Silver',
  1965,
  1965,
  true
FROM public.synagogues
WHERE name = 'Israel Congregation'
LIMIT 1;

-- 241. Benjamin A. Samson at Israel Congregation (1966-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Benjamin A. Samson',
  1966,
  1966,
  true
FROM public.synagogues
WHERE name = 'Israel Congregation'
LIMIT 1;

-- 242. Abraham Lemont at Israel Congregation (1967-1972.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham Lemont',
  1967,
  1972,
  true
FROM public.synagogues
WHERE name = 'Israel Congregation'
LIMIT 1;

-- 243. Aaron S. Gold at Mount Airy Jewish Community Center (1961-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron S. Gold',
  1961,
  1964,
  true
FROM public.synagogues
WHERE name = 'Mount Airy Jewish Community Center'
LIMIT 1;

-- 244. David Clayman at Ramat El (1965-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Clayman',
  1965,
  1969,
  true
FROM public.synagogues
WHERE name = 'Ramat El'
LIMIT 1;

-- 245. Louis L. Sacks at Ramat El (1970-1981.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis L. Sacks',
  1970,
  1981,
  true
FROM public.synagogues
WHERE name = 'Ramat El'
LIMIT 1;

-- 246. Edward M. Maline at Ramat El (1983-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Edward M. Maline',
  1983,
  1983,
  true
FROM public.synagogues
WHERE name = 'Ramat El'
LIMIT 1;

-- 247. Samuel Shore (Cantor) at See, Neziner Congregation (1963-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Samuel Shore (Cantor)',
  1963,
  1969,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 248. Abraham Dubow (Cantor) at See, Neziner Congregation (1970-1972.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham Dubow (Cantor)',
  1970,
  1972,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 249. Mark I. Goldhirsh (Cantor) at See, Neziner Congregation (1973-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mark I. Goldhirsh (Cantor)',
  1973,
  1973,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 250. Abraham Spak (Cantor) at See, Neziner Congregation (1974-1974.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham Spak (Cantor)',
  1974,
  1974,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 251. Simon Kedar (Cantor) at See, Neziner Congregation (1975-1975.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Simon Kedar (Cantor)',
  1975,
  1975,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 252. Henry Shane (Cantor) at See, Neziner Congregation (1976-1981.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Henry Shane (Cantor)',
  1976,
  1981,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 253. Saul I. Wisemon at See, Neziner Congregation (1982-1982.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Saul I. Wisemon',
  1982,
  1982,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 254. David Maharam at Yeadon Jewish Community Center (1982-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Maharam',
  1982,
  1988,
  true
FROM public.synagogues
WHERE name = 'Yeadon Jewish Community Center'
LIMIT 1;

-- 255. Aaron Popack at Northeast Orthodox Congregation (1961-1976.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Popack',
  1961,
  1976,
  true
FROM public.synagogues
WHERE name = 'Northeast Orthodox Congregation'
LIMIT 1;

-- 256. Jarsol Wiesman (Cantor) at Ohel Jacob (1962-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jarsol Wiesman (Cantor)',
  1962,
  1963,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob'
LIMIT 1;

-- 257. Jacob Frankel (Cantor) at Ohel Jacob (1964-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jacob Frankel (Cantor)',
  1964,
  1964,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob'
LIMIT 1;

-- 258. David Wachtfogel, Joshua Wachtfogel at Ohel Jacob of Oxford Circle (1962-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Wachtfogel, Joshua Wachtfogel',
  1962,
  1969,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob of Oxford Circle'
LIMIT 1;

-- 259. Joshua Wachtfogel at Ohel Jacob of Oxford Circle (1973-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joshua Wachtfogel',
  1973,
  1973,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob of Oxford Circle'
LIMIT 1;

-- 260. Irwin Lubin at Ohel Jacob of Oxford Circle (1975-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Irwin Lubin',
  1975,
  1980,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob of Oxford Circle'
LIMIT 1;

-- 261. Abraham Slivko at Ohel Jacob of Oxford Circle (1981-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham Slivko',
  1981,
  1983,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob of Oxford Circle'
LIMIT 1;

-- 262. Louis Kaplan at Ohev Shalom (1961-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis Kaplan',
  1961,
  1991,
  true
FROM public.synagogues
WHERE name = 'Ohev Shalom'
LIMIT 1;

-- 263. Stephen Grundfast at Ohev Shalom (1992-2000.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Stephen Grundfast',
  1992,
  2000,
  true
FROM public.synagogues
WHERE name = 'Ohev Shalom'
LIMIT 1;

-- 264. Louis Kaplan at Ohev Shalom (2001-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis Kaplan',
  2001,
  2001,
  true
FROM public.synagogues
WHERE name = 'Ohev Shalom'
LIMIT 1;

-- 265. Mark Robbins at Ohev Shalom (2002-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mark Robbins',
  2002,
  2008,
  true
FROM public.synagogues
WHERE name = 'Ohev Shalom'
LIMIT 1;

-- 266. Jeremy Gerber at Ohev Shalom (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jeremy Gerber',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Ohev Shalom'
LIMIT 1;

-- 267. Eliott N. Perlstein at Ohev Sholom of Bucks County (1978-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eliott N. Perlstein',
  1978,
  2017,
  true
FROM public.synagogues
WHERE name = 'Ohev Sholom of Bucks County'
LIMIT 1;

-- 268. Israel E. Turner at Ohev Zedek (1955-1959.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Israel E. Turner',
  1955,
  1959,
  true
FROM public.synagogues
WHERE name = 'Ohev Zedek'
LIMIT 1;

-- 269. G. Bernard Schwartz at Ohev Zedek (1961-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'G. Bernard Schwartz',
  1961,
  1967,
  true
FROM public.synagogues
WHERE name = 'Ohev Zedek'
LIMIT 1;

-- 270. Tsvi G. Schur at Ohev Zedek (1970-1971.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Tsvi G. Schur',
  1970,
  1971,
  true
FROM public.synagogues
WHERE name = 'Ohev Zedek'
LIMIT 1;

-- 271. Harold B. Waintrup at Old York Road Temple- Beth Am (1961-1990.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harold B. Waintrup',
  1961,
  1990,
  true
FROM public.synagogues
WHERE name = 'Old York Road Temple- Beth Am'
LIMIT 1;

-- 272. Robert S. Leib at Old York Road Temple- Beth Am (1991-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert S. Leib',
  1991,
  2017,
  true
FROM public.synagogues
WHERE name = 'Old York Road Temple- Beth Am'
LIMIT 1;

-- 273. Kenneth Bromberg at Yeadon Jewish Community Center (1949-1949.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Kenneth Bromberg',
  1949,
  1949,
  true
FROM public.synagogues
WHERE name = 'Yeadon Jewish Community Center'
LIMIT 1;

-- 274. Tibor Fabian at Or Ami. See also, Ivy Ridge Jewish Community Center (1961-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Tibor Fabian',
  1961,
  1962,
  true
FROM public.synagogues
WHERE name = 'Or Ami. See also, Ivy Ridge Jewish Community Center'
LIMIT 1;

-- 275. Kenneth I. Carr at Or Ami. See also, Ivy Ridge Jewish Community Center (2001-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Kenneth I. Carr',
  2001,
  2017,
  true
FROM public.synagogues
WHERE name = 'Or Ami. See also, Ivy Ridge Jewish Community Center'
LIMIT 1;

-- 276. David A. Goldstein at Or Shalom (1978-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David A. Goldstein',
  1978,
  1984,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 277. David Wortman at Or Shalom (1985-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Wortman',
  1985,
  1987,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 278. Ronald W. Kaplan at Or Shalom (1989-1992.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Ronald W. Kaplan',
  1989,
  1992,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 279. Mitchell Romirowsky at Or Shalom (2008-2009.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mitchell Romirowsky',
  2008,
  2009,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 280. Barry Rosen at Beth Tfilla of Overbrook Park (1987-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Barry Rosen',
  1987,
  1997,
  true
FROM public.synagogues
WHERE name = 'Beth Tfilla of Overbrook Park'
LIMIT 1;

-- 281. Robert Rubin at Beth Tfilla of Overbrook Park (1998-2006.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Robert Rubin',
  1998,
  2006,
  true
FROM public.synagogues
WHERE name = 'Beth Tfilla of Overbrook Park'
LIMIT 1;

-- 282. Leon Stitskin at Oxford Circle Jewish Community Center-                  Beth Israel (1952-1953.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Leon Stitskin',
  1952,
  1953,
  true
FROM public.synagogues
WHERE name = 'Oxford Circle Jewish Community Center-                  Beth Israel'
LIMIT 1;

-- 283. J. Harold Romirowsky at Oxford Circle Jewish Community Center-                  Beth Israel (1954-1999.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'J. Harold Romirowsky',
  1954,
  1999,
  true
FROM public.synagogues
WHERE name = 'Oxford Circle Jewish Community Center-                  Beth Israel'
LIMIT 1;

-- 284. Eugene A. Wernick at Oxford Circle Jewish Community Center-                  Beth Israel (2000-2003.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Eugene A. Wernick',
  2000,
  2003,
  true
FROM public.synagogues
WHERE name = 'Oxford Circle Jewish Community Center-                  Beth Israel'
LIMIT 1;

-- 285. Daniel Bonchek at Pennypack Jewish Community Center (1963-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Daniel Bonchek',
  1963,
  1963,
  true
FROM public.synagogues
WHERE name = 'Pennypack Jewish Community Center'
LIMIT 1;

-- 286. Yaakov I. Homnick at Beth Tefilath Israel of Pennypack Park (1966-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yaakov I. Homnick',
  1966,
  1967,
  true
FROM public.synagogues
WHERE name = 'Beth Tefilath Israel of Pennypack Park'
LIMIT 1;

-- 287. Harvey Gornish (Associate) at Raim Ahuvim (2005-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harvey Gornish (Associate)',
  2005,
  2017,
  true
FROM public.synagogues
WHERE name = 'Raim Ahuvim'
LIMIT 1;

-- 288. Sidney B. Ribeck at Rhawnhurst Jewish Center (1961-1973.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sidney B. Ribeck',
  1961,
  1973,
  true
FROM public.synagogues
WHERE name = 'Rhawnhurst Jewish Center'
LIMIT 1;

-- 289. David Leiter at Adath Tikvah - Montefiore (1974-1976.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Leiter',
  1974,
  1976,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 290. Bruce E. Harbater at Adath Tikvah - Montefiore (1979-1981.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Bruce E. Harbater',
  1979,
  1981,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 291. Brian Walt at Adath Tikvah - Montefiore (1982-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Brian Walt',
  1982,
  1983,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 292. L. Aryeh Alpern at Adath Tikvah - Montefiore (1984-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'L. Aryeh Alpern',
  1984,
  1984,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 293. Howard Cove at Adath Tikvah - Montefiore (1986-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Howard Cove',
  1986,
  1987,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 294. Reuben Israel Abraham at Adath Tikvah - Montefiore (1988-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Reuben Israel Abraham',
  1988,
  1997,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 295. Jonathan David Malamy at Adath Tikvah - Montefiore (1998-1999.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jonathan David Malamy',
  1998,
  1999,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 296. David C. Novitsky at Adath Tikvah - Montefiore (2000-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David C. Novitsky',
  2000,
  2001,
  true
FROM public.synagogues
WHERE name = 'Adath Tikvah - Montefiore'
LIMIT 1;

-- 297. Louis Wolsey at Rodeph Shalom (1925-1947.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis Wolsey',
  1925,
  1947,
  true
FROM public.synagogues
WHERE name = 'Rodeph Shalom'
LIMIT 1;

-- 298. David H. Wice at Rodeph Shalom (1953-1979.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David H. Wice',
  1953,
  1979,
  true
FROM public.synagogues
WHERE name = 'Rodeph Shalom'
LIMIT 1;

-- 299. Alan D. Fuchs at Rodeph Shalom (1990-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Alan D. Fuchs',
  1990,
  1997,
  true
FROM public.synagogues
WHERE name = 'Rodeph Shalom'
LIMIT 1;

-- 300. William I. Kuhn at Rodeph Shalom (1998-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'William I. Kuhn',
  1998,
  2017,
  true
FROM public.synagogues
WHERE name = 'Rodeph Shalom'
LIMIT 1;

-- 301. Abraham L. Poupko at Shaarei Eli (1961-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham L. Poupko',
  1961,
  1963,
  true
FROM public.synagogues
WHERE name = 'Shaarei Eli'
LIMIT 1;

-- 302. Yedidya Dagowitz at Shaarei Eli (1974-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Yedidya Dagowitz',
  1974,
  1983,
  true
FROM public.synagogues
WHERE name = 'Shaarei Eli'
LIMIT 1;

-- 303. Joseph Wintner at Greater Northeast Congregation (1949-1949.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph Wintner',
  1949,
  1949,
  true
FROM public.synagogues
WHERE name = 'Greater Northeast Congregation'
LIMIT 1;

-- 304. Dayle Friedman at Shaare Zedek. (1988-1996.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Dayle Friedman',
  1988,
  1996,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 305. Natan Fenner at Shaare Zedek. (1997-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Natan Fenner',
  1997,
  2001,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 306. Avraham Hartman at Shaare Zedek. (1961-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Avraham Hartman',
  1961,
  1961,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 307. Mordecai Weintraub at Shaare Zedek. (1961-1968.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mordecai Weintraub',
  1961,
  1968,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 308. Herman Budnick at Shaare Zedek. (1969-1976.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Herman Budnick',
  1969,
  1976,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 309. Ivan Caine at Society Hill Synagogue (1969-2000.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Ivan Caine',
  1969,
  2000,
  true
FROM public.synagogues
WHERE name = 'Society Hill Synagogue'
LIMIT 1;

-- 310. Avi Winokur at Society Hill Synagogue (2001-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Avi Winokur',
  2001,
  2017,
  true
FROM public.synagogues
WHERE name = 'Society Hill Synagogue'
LIMIT 1;

-- 311. Herman L. Horowitz at Suburban Jewish Community Center-B'nai Aaron (1968-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Herman L. Horowitz',
  1968,
  1969,
  true
FROM public.synagogues
WHERE name = 'Suburban Jewish Community Center-B''nai Aaron'
LIMIT 1;

-- 312. Morris V. Dembowitz at Suburban Jewish Community Center-B'nai Aaron (1970-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Morris V. Dembowitz',
  1970,
  1980,
  true
FROM public.synagogues
WHERE name = 'Suburban Jewish Community Center-B''nai Aaron'
LIMIT 1;

-- 313. Martin I. Sandberg at Suburban Jewish Community Center-B'nai Aaron (1981-2003.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Martin I. Sandberg',
  1981,
  2003,
  true
FROM public.synagogues
WHERE name = 'Suburban Jewish Community Center-B''nai Aaron'
LIMIT 1;

-- 314. Lisa S. Malik at Suburban Jewish Community Center-B'nai Aaron (2004-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Lisa S. Malik',
  2004,
  2017,
  true
FROM public.synagogues
WHERE name = 'Suburban Jewish Community Center-B''nai Aaron'
LIMIT 1;

-- 315. Daniel P. Parker at Temple Isaiah (1996-2003.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Daniel P. Parker',
  1996,
  2003,
  true
FROM public.synagogues
WHERE name = 'Temple Isaiah'
LIMIT 1;

-- 316. Allan M. Langner at Temple Israel of Upper Darby (1956-1959.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Allan M. Langner',
  1956,
  1959,
  true
FROM public.synagogues
WHERE name = 'Temple Israel of Upper Darby'
LIMIT 1;

-- 317. Jerome Weistrop at Temple Israel of Upper Darby (1960-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jerome Weistrop',
  1960,
  1966,
  true
FROM public.synagogues
WHERE name = 'Temple Israel of Upper Darby'
LIMIT 1;

-- 318. Jerome S. Bass at Temple Israel of Upper Darby (1967-1971.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jerome S. Bass',
  1967,
  1971,
  true
FROM public.synagogues
WHERE name = 'Temple Israel of Upper Darby'
LIMIT 1;

-- 319. Maurice S. Corson at Temple Israel of Upper Darby (1973-1975.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Maurice S. Corson',
  1973,
  1975,
  true
FROM public.synagogues
WHERE name = 'Temple Israel of Upper Darby'
LIMIT 1;

-- 320. Mitchell Smith at Temple Israel of Upper Darby (1976-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mitchell Smith',
  1976,
  1977,
  true
FROM public.synagogues
WHERE name = 'Temple Israel of Upper Darby'
LIMIT 1;

-- 321. Martin Rubenstein at Temple Israel of Upper Darby (1978-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Martin Rubenstein',
  1978,
  2001,
  true
FROM public.synagogues
WHERE name = 'Temple Israel of Upper Darby'
LIMIT 1;

-- 322. Morton Rosenthal at Temple Judea of Bucks County (1981-1982.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Morton Rosenthal',
  1981,
  1982,
  true
FROM public.synagogues
WHERE name = 'Temple Judea of Bucks County'
LIMIT 1;

-- 323. Jeffrey Salkin at Temple Judea of Bucks County (1983-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jeffrey Salkin',
  1983,
  1987,
  true
FROM public.synagogues
WHERE name = 'Temple Judea of Bucks County'
LIMIT 1;

-- 324. Barbara Goldman-Wartell at Temple Judea of Bucks County (1988-1996.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Barbara Goldman-Wartell',
  1988,
  1996,
  true
FROM public.synagogues
WHERE name = 'Temple Judea of Bucks County'
LIMIT 1;

-- 325. Lawrence Colton at Temple Judea of Bucks County (1997-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Lawrence Colton',
  1997,
  1997,
  true
FROM public.synagogues
WHERE name = 'Temple Judea of Bucks County'
LIMIT 1;

-- 326. Kennath Weiss at Temple Judea of Bucks County (1998-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Kennath Weiss',
  1998,
  2001,
  true
FROM public.synagogues
WHERE name = 'Temple Judea of Bucks County'
LIMIT 1;

-- 327. Gary Pokras at Temple Judea of Bucks County (2002-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gary Pokras',
  2002,
  2017,
  true
FROM public.synagogues
WHERE name = 'Temple Judea of Bucks County'
LIMIT 1;

-- 328. Abraham H. Israelitan at Fox Chase Jewish Community Center (1951-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abraham H. Israelitan',
  1951,
  1986,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 329. Herbert Hendel at Temple Shalom (1961-1970.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Herbert Hendel',
  1961,
  1970,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 330. Laurence Rubinstein at Temple Shalom (1972-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Laurence Rubinstein',
  1972,
  1977,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 331. Gordon L. Geller at Temple Shalom (1978-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gordon L. Geller',
  1978,
  1983,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 332. Arthur P. Nemitoff at Temple Shalom (1984-1988.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Arthur P. Nemitoff',
  1984,
  1988,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 333. Allan C. Tuffs at Temple Shalom (1989-1996.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Allan C. Tuffs',
  1989,
  1996,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 334. Shelley Kovar Becker at Temple Shalom (1997-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Shelley Kovar Becker',
  1997,
  1997,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 335. Glenn M. Jacob at Temple Shalom (1998-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Glenn M. Jacob',
  1998,
  2008,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 336. Annette Koch at Temple Shalom (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Annette Koch',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 337. Pinchos J. Chazin at Temple Shalom (1950-1990.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Pinchos J. Chazin',
  1950,
  1990,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 338. Mitchell Romirowsky at Temple Shalom (1992-1993.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mitchell Romirowsky',
  1992,
  1993,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 339. Brian E. Glusman at Temple Shalom (1995-1996.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Brian E. Glusman',
  1995,
  1996,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 340. Andrea L. Merow at Temple Shalom (1997-2003.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Andrea L. Merow',
  1997,
  2003,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 341. Harold Rubens at Temple Shalom (1961-1963.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harold Rubens',
  1961,
  1963,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 342. Milton Shulman at Temple Shalom (1964-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Milton Shulman',
  1964,
  1966,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 343. Paul Swerdlow at Temple Shalom (1967-1970.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Paul Swerdlow',
  1967,
  1970,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 344. Meyer W. Selekman at Temple Shalom (1971-1998.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Meyer W. Selekman',
  1971,
  1998,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 345. Peter E. Hyman at Temple Shalom (1999-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Peter E. Hyman',
  1999,
  2008,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 346. Peter C. Rigler at Temple Shalom (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Peter C. Rigler',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 347. Steven Fineblum at Temple Sinai (1976-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Steven Fineblum',
  1976,
  1977,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 348. Daniel T. Grossman at Temple Sinai (1985-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Daniel T. Grossman',
  1985,
  1987,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 349. Howard K. Cove at Temple Sinai (1988-1995.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Howard K. Cove',
  1988,
  1995,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 350. Howard A. Addison at Temple Sinai (1995-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Howard A. Addison',
  1995,
  2001,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 351. Adam M. Wohlberg at Temple Sinai (2002-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Adam M. Wohlberg',
  2002,
  2017,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 352. Albert Ginsburgh at Temple Zion (1961-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Albert Ginsburgh',
  1961,
  1961,
  true
FROM public.synagogues
WHERE name = 'Temple Zion'
LIMIT 1;

-- 353. Martin Bronenberg at Tiferes B'nai Israel (1971-1983.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Martin Bronenberg',
  1971,
  1983,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 354. Stephen Berkowitz at Tiferes B'nai Israel (1984-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Stephen Berkowitz',
  1984,
  1984,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 355. Sandra R. Berliner at Tiferes B'nai Israel (1985-1987.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sandra R. Berliner',
  1985,
  1987,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 356. Shai Glushin at Tiferes B'nai Israel (1996-1998.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Shai Glushin',
  1996,
  1998,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 357. Jon E. Cutler at Tiferes B'nai Israel (1999-2007.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jon E. Cutler',
  1999,
  2007,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 358. Jeff Sultar at Tiferes B'nai Israel (2009-2009.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jeff Sultar',
  2009,
  2009,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 359. Seth Frisch at Tiferes B'nai Israel (2010-2010.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Seth Frisch',
  2010,
  2010,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 360. David Maharam at Tiferet Bet Israel (1989-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David Maharam',
  1989,
  1991,
  true
FROM public.synagogues
WHERE name = 'Tiferet Bet Israel'
LIMIT 1;

-- 361. David M. Ackerman at Tiferet Bet Israel (1992-2007.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'David M. Ackerman',
  1992,
  2007,
  true
FROM public.synagogues
WHERE name = 'Tiferet Bet Israel'
LIMIT 1;

-- 362. Harold Shuman (Acting) at Tifereth Israel Anshe Lita (1962-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harold Shuman (Acting)',
  1962,
  1965,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel Anshe Lita'
LIMIT 1;

-- 363. Gershon Schwartz at Tiferet Israel of Lower Bucks County (1979-1982.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gershon Schwartz',
  1979,
  1982,
  true
FROM public.synagogues
WHERE name = 'Tiferet Israel of Lower Bucks County'
LIMIT 1;

-- 364. Harvey Spivak at Tiferet Israel of Lower Bucks County (1983-1986.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harvey Spivak',
  1983,
  1986,
  true
FROM public.synagogues
WHERE name = 'Tiferet Israel of Lower Bucks County'
LIMIT 1;

-- 365. Moshe Saks at Tiferet Israel of Lower Bucks County (1987-1996.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Moshe Saks',
  1987,
  1996,
  true
FROM public.synagogues
WHERE name = 'Tiferet Israel of Lower Bucks County'
LIMIT 1;

-- 366. Michael L. Rascoe at Tiferet Israel of Lower Bucks County (1997-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Michael L. Rascoe',
  1997,
  1997,
  true
FROM public.synagogues
WHERE name = 'Tiferet Israel of Lower Bucks County'
LIMIT 1;

-- 367. Jeffery Schnitzer at Tiferet Israel of Lower Bucks County (1999-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jeffery Schnitzer',
  1999,
  2017,
  true
FROM public.synagogues
WHERE name = 'Tiferet Israel of Lower Bucks County'
LIMIT 1;

-- 368. A. Novitsky at Tifereth Israel of Parkside (1961-1961.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'A. Novitsky',
  1961,
  1961,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel of Parkside'
LIMIT 1;

-- 369. Nathan M. Bernstein at Tikvas Israel (1950-nan)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Nathan M. Bernstein',
  1950,
  NULL,
  true
FROM public.synagogues
WHERE name = 'Tikvas Israel'
LIMIT 1;

-- 370. Irvin Brodie (Acting) at Tikvas Israel (1962-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Irvin Brodie (Acting)',
  1962,
  1964,
  true
FROM public.synagogues
WHERE name = 'Tikvas Israel'
LIMIT 1;

-- 371. Joseph L. Herbst at Tikvoh Chadoshoh (1961-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph L. Herbst',
  1961,
  1964,
  true
FROM public.synagogues
WHERE name = 'Tikvoh Chadoshoh'
LIMIT 1;

-- 372. William Eisenberg (Acting) at Tikvoh Chadoshoh (1965-1980.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'William Eisenberg (Acting)',
  1965,
  1980,
  true
FROM public.synagogues
WHERE name = 'Tikvoh Chadoshoh'
LIMIT 1;

-- 373. Caryn Broitman at Tzedek V'Shalom (1996-2002.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Caryn Broitman',
  1996,
  2002,
  true
FROM public.synagogues
WHERE name = 'Tzedek V''Shalom'
LIMIT 1;

-- 374. Sigal Dagan Brier at Tzedek V'Shalom (2003-2007.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Sigal Dagan Brier',
  2003,
  2007,
  true
FROM public.synagogues
WHERE name = 'Tzedek V''Shalom'
LIMIT 1;

-- 375. Anna Boswell-Levy at Tzedek V'Shalom (2008-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Anna Boswell-Levy',
  2008,
  2017,
  true
FROM public.synagogues
WHERE name = 'Tzedek V''Shalom'
LIMIT 1;

-- 376. Meryl M. Crean at Beth Chaim Reform Congregation (1996-1997.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Meryl M. Crean',
  1996,
  1997,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 377. Marjorie Yudkin at Beth Chaim Reform Congregation (1998-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Marjorie Yudkin',
  1998,
  2001,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 378. Alex J. Goldman at West Oak Lane Jewish Community Center (1959-1966.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Alex J. Goldman',
  1959,
  1966,
  true
FROM public.synagogues
WHERE name = 'West Oak Lane Jewish Community Center'
LIMIT 1;

-- 379. Seymour L. Schorr at West Oak Lane Jewish Community Center (1967-1971.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Seymour L. Schorr',
  1967,
  1971,
  true
FROM public.synagogues
WHERE name = 'West Oak Lane Jewish Community Center'
LIMIT 1;

-- 380. Fredric Kazan at West Oak Lane Jewish Community Center (1972-1977.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Fredric Kazan',
  1972,
  1977,
  true
FROM public.synagogues
WHERE name = 'West Oak Lane Jewish Community Center'
LIMIT 1;

-- 381. C. David Matt at West Philadelphia Jewish Community Center (1936-1951.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'C. David Matt',
  1936,
  1951,
  true
FROM public.synagogues
WHERE name = 'West Philadelphia Jewish Community Center'
LIMIT 1;

-- 382. Edward M. Tannenbaum at West Philadelphia Jewish Community Center (1953-1957.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Edward M. Tannenbaum',
  1953,
  1957,
  true
FROM public.synagogues
WHERE name = 'West Philadelphia Jewish Community Center'
LIMIT 1;

-- 383. Maurice S. Newhoff at West Philadelphia Jewish Community Center (1960-1960.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Maurice S. Newhoff',
  1960,
  1960,
  true
FROM public.synagogues
WHERE name = 'West Philadelphia Jewish Community Center'
LIMIT 1;

-- 384. Chaim Potok at Fox Chase Jewish Community Center (1964-1964.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Chaim Potok',
  1964,
  1964,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 385. Matthew S. Rosen at Wynnefield Jewish Center (1962-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Matthew S. Rosen',
  1962,
  1969,
  true
FROM public.synagogues
WHERE name = 'Wynnefield Jewish Center'
LIMIT 1;

-- 386. Louis Parris at Congregation (1961-1965.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis Parris',
  1961,
  1965,
  true
FROM public.synagogues
WHERE name = 'Congregation'
LIMIT 1;

-- 387. Arnold G. Kaiman at Congregation (1967-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Arnold G. Kaiman',
  1967,
  1967,
  true
FROM public.synagogues
WHERE name = 'Congregation'
LIMIT 1;

-- 388. Hyman Harris at Yavneh Synagogue (1963-1967.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Hyman Harris',
  1963,
  1967,
  true
FROM public.synagogues
WHERE name = 'Yavneh Synagogue'
LIMIT 1;

-- 389. Charles Lacks at Yeadon Jewish Community Center (1961-1975.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Charles Lacks',
  1961,
  1975,
  true
FROM public.synagogues
WHERE name = 'Yeadon Jewish Community Center'
LIMIT 1;

-- 390. Charles I. Kraus at Yeadon Jewish Community Center (1976-1990.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Charles I. Kraus',
  1976,
  1990,
  true
FROM public.synagogues
WHERE name = 'Yeadon Jewish Community Center'
LIMIT 1;

-- 391. Julius Meles at Young Israel of Oxford Circle (1961-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Julius Meles',
  1961,
  2008,
  true
FROM public.synagogues
WHERE name = 'Young Israel of Oxford Circle'
LIMIT 1;

-- 392. Aron Gold at Young Israel of the Main Line (1981-1981.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aron Gold',
  1981,
  1981,
  true
FROM public.synagogues
WHERE name = 'Young Israel of the Main Line'
LIMIT 1;

-- 393. Leibel Chaitowsky at Young Israel of the Main Line (1983-1984.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Leibel Chaitowsky',
  1983,
  1984,
  true
FROM public.synagogues
WHERE name = 'Young Israel of the Main Line'
LIMIT 1;

-- 394. Mordecai H. Young at Young Israel of the Main Line (1989-2004.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mordecai H. Young',
  1989,
  2004,
  true
FROM public.synagogues
WHERE name = 'Young Israel of the Main Line'
LIMIT 1;

-- 395. Avraham Steinberg at Young Israel of the Main Line (2005-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Avraham Steinberg',
  2005,
  2017,
  true
FROM public.synagogues
WHERE name = 'Young Israel of the Main Line'
LIMIT 1;

-- 396. Stanley Math at Young People's Congregation - Shari Eli. (1955-1956.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Stanley Math',
  1955,
  1956,
  true
FROM public.synagogues
WHERE name = 'Young People''s Congregation - Shari Eli.'
LIMIT 1;

-- 397. Harry B. Kellman at Beth El (1960-1962.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Harry B. Kellman',
  1960,
  1962,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 398. Howard Kahn at Beth El (1970-1994.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Howard Kahn',
  1970,
  1994,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 399. Howard Kahn, Aaron Krupnick at Beth El (1997-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Howard Kahn, Aaron Krupnick',
  1997,
  2001,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 400. Aaron Krupnick, Jeffrey Arnowitz, Isaac Furman at Beth El (2004-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Krupnick, Jeffrey Arnowitz, Isaac Furman',
  2004,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 401. Aaron Krupnick, Noah Arnow, Isaac Furman at Beth El (2011-2013.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Krupnick, Noah Arnow, Isaac Furman',
  2011,
  2013,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 402. Aaron Krupnick, Isaac Furman at Beth El (2014-2015.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Krupnick, Isaac Furman',
  2014,
  2015,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 403. Aaron Krupnick, Andy Green, Isaac Furman at Beth El (2016-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Aaron Krupnick, Andy Green, Isaac Furman',
  2016,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 404. Abby Michaleski at Beth El (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Abby Michaleski',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 405. Rayzel Raphael at Brith Israel Congregation (2009-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Rayzel Raphael',
  2009,
  2017,
  true
FROM public.synagogues
WHERE name = 'Brith Israel Congregation'
LIMIT 1;

-- 406. George Vida at Beth Solomon (1940-1945.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'George Vida',
  1940,
  1945,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 407. Hershel Levine at Beth Solomon (1946-1947.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Hershel Levine',
  1946,
  1947,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 408. Albert L. Lewis at Beth Solomon (1948-1992.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Albert L. Lewis',
  1948,
  1992,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 409. Stephen C. Lindemann at Beth Solomon (1992-2014.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Stephen C. Lindemann',
  1992,
  2014,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 410. Micah Peltz at Beth Solomon (2014-nan)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Micah Peltz',
  2014,
  NULL,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 411. Joshua Waxman at Tiferes B'nai Israel (1999-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joshua Waxman',
  1999,
  2001,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 412. Joseph M. Domosh at Tiferes B'nai Israel (2009-2014.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Joseph M. Domosh',
  2009,
  2014,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 413. Mandel Mangel at Chabad Lubavitch of Bucks County (2008-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Mandel Mangel',
  2008,
  2017,
  true
FROM public.synagogues
WHERE name = 'Chabad Lubavitch of Bucks County'
LIMIT 1;

-- 414. Fred Neulander at Or Shalom (1991-1991.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Fred Neulander',
  1991,
  1991,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 415. Fred Neulander, Gary A. Mazo at Or Shalom (1992-1994.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Fred Neulander, Gary A. Mazo',
  1992,
  1994,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 416. Gary A. Mazo, Bruce Elder at Or Shalom (1997-1998.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Gary A. Mazo, Bruce Elder',
  1997,
  1998,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 417. Barry Schwartz, Ari Goldstein at Or Shalom (1999-2001.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Barry Schwartz, Ari Goldstein',
  1999,
  2001,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 418. Barry Schwartz, Alana Wasserman at Or Shalom (2004-2007.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Barry Schwartz, Alana Wasserman',
  2004,
  2007,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 419. Michael Satz at Or Shalom (2008-2008.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Michael Satz',
  2008,
  2008,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 420. Barry L. Schwartz,  Jennifer L. Frenkel at Or Shalom (2009-2009.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Barry L. Schwartz,  Jennifer L. Frenkel',
  2009,
  2009,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 421. Darryl P. Crystal, Jennifer L. Frenkel at Or Shalom (2010-2011.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Darryl P. Crystal, Jennifer L. Frenkel',
  2010,
  2011,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 422. Richard F. Address, Jennifer L. Frenkel at Or Shalom (2012-2013.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Richard F. Address, Jennifer L. Frenkel',
  2012,
  2013,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 423. Jennifer L. Frenkel, Annette R. Koch at Or Shalom (2014-2014.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jennifer L. Frenkel, Annette R. Koch',
  2014,
  2014,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 424. Jennifer L. Frenkel at Or Shalom (2015-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jennifer L. Frenkel',
  2015,
  2017,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 425. Andrew I. Bossov at Adath Emanu-el (2005-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Andrew I. Bossov',
  2005,
  2017,
  true
FROM public.synagogues
WHERE name = 'Adath Emanu-el'
LIMIT 1;

-- 426. Stacy K. Offner at Adath Emanu-el (2011-2011.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Stacy K. Offner',
  2011,
  2011,
  true
FROM public.synagogues
WHERE name = 'Adath Emanu-el'
LIMIT 1;

-- 427. Benjamin P. David at Adath Emanu-el (2012-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Benjamin P. David',
  2012,
  2017,
  true
FROM public.synagogues
WHERE name = 'Adath Emanu-el'
LIMIT 1;

-- 428. Jonas Goldberg at Temple Sinai (1969-1969.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Jonas Goldberg',
  1969,
  1969,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 429. Louis H. Lieberworth at Temple Sinai (1970-1972.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Louis H. Lieberworth',
  1970,
  1972,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 430. Steven N. Fineblum at Temple Sinai (1991-2015.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Steven N. Fineblum',
  1991,
  2015,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 431. Boaz Marmon at Temple Sinai (2016-2017.0)
INSERT INTO public.rabbis (
  synagogue_id, name, start_year, end_year, approved
)
SELECT 
  id,
  'Boaz Marmon',
  2016,
  2017,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- ============================================================================
-- SECTION 4: ADDRESS DATA - UPDATES (Add Year Ranges)
-- ============================================================================
-- Updating 63 address records with year ranges

-- 1. Adath Jeshurun: 2109 N Broad St
UPDATE public.addresses
SET start_year = 1936,
    end_year = 1959,
    is_current = CASE 
      WHEN 1959 IS NULL THEN true
      WHEN 1959 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Adath Jeshurun'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%2109 n broad st%';

-- 2. Adath Jeshurun: 7763 Old York Rd
UPDATE public.addresses
SET start_year = 1994,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Adath Jeshurun'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%7763 old york rd%';

-- 3. Aitz Chaim Synagogue Center: 7600 Summerdale Ave
UPDATE public.addresses
SET start_year = 1966,
    end_year = 2002,
    is_current = CASE 
      WHEN 2002 IS NULL THEN true
      WHEN 2002 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Aitz Chaim Synagogue Center'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%7600 summerdale ave%';

-- 4. Anshe Sholem: 1924-6 Germantown Ave
UPDATE public.addresses
SET start_year = 1961,
    end_year = 1969,
    is_current = CASE 
      WHEN 1969 IS NULL THEN true
      WHEN 1969 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Anshe Sholem'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1924-6 germantown ave%';

-- 5. Beth Am Israel: 1301 Hagys Ford Rd
UPDATE public.addresses
SET start_year = 1973,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Am Israel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1301 hagys ford rd%';

-- 6. Beth Chaim Reform Congregation: 389 Conestoga Rd
UPDATE public.addresses
SET start_year = 2017,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Chaim Reform Congregation'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%389 conestoga rd%';

-- 7. Beth El of Bucks County: 375 Stony Hill Rd
UPDATE public.addresses
SET start_year = 1997,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth El of Bucks County'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%375 stony hill rd%';

-- 8. Beth El, Suburban: 715 Paxon Hollow Rd
UPDATE public.addresses
SET start_year = 1961,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth El, Suburban'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%715 paxon hollow rd%';

-- 9. Beth Emeth.: Bustleton & Unruh Aves
UPDATE public.addresses
SET start_year = 1952,
    end_year = 2001,
    is_current = CASE 
      WHEN 2001 IS NULL THEN true
      WHEN 2001 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Emeth.'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%bustleton & unruh aves%';

-- 10. Beth HaMedrosh Hagodol-Beth Yaacov: 6018 Larchwood Ave
UPDATE public.addresses
SET start_year = 1962,
    end_year = 1991,
    is_current = CASE 
      WHEN 1991 IS NULL THEN true
      WHEN 1991 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth HaMedrosh Hagodol-Beth Yaacov'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%6018 larchwood ave%';

-- 11. Beth HaMedrash: 200 Haverford Rd
UPDATE public.addresses
SET start_year = 2007,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth HaMedrash'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%200 haverford rd%';

-- 12. Beth Israel: 32nd St & Montgomery Ave
UPDATE public.addresses
SET start_year = 1950,
    end_year = 1956,
    is_current = CASE 
      WHEN 1956 IS NULL THEN true
      WHEN 1956 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Israel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%32nd st & montgomery ave%';

-- 13. Beth Israel Congregation of Chester County: 385 Pottstown Pike
UPDATE public.addresses
SET start_year = 1995,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Israel Congregation of Chester County'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%385 pottstown pike%';

-- 14. Beth Solomon Suburban (of Somerton): 198 Tomlinson Rd
UPDATE public.addresses
SET start_year = 1999,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Solomon Suburban (of Somerton)'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%198 tomlinson rd%';

-- 15. Beth Uziel: 41 E. Wyoming Ave
UPDATE public.addresses
SET start_year = 1950,
    end_year = 1954,
    is_current = CASE 
      WHEN 1954 IS NULL THEN true
      WHEN 1954 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Uziel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%41 e wyoming ave%';

-- 16. Beth Zion-Beth Israel [Temple]: 300 South 18th St
UPDATE public.addresses
SET start_year = 1995,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Zion-Beth Israel [Temple]'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%300 south 18th st%';

-- 17. B'nai Abraham Jewish Center: 9037 Eastview St
UPDATE public.addresses
SET start_year = 1983,
    end_year = 1986,
    is_current = CASE 
      WHEN 1986 IS NULL THEN true
      WHEN 1986 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'B''nai Abraham Jewish Center'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%9037 eastview st%';

-- 18. B'nai Israel of Olney: 307 W. Tabor Rd
UPDATE public.addresses
SET start_year = 1949,
    end_year = 1955,
    is_current = CASE 
      WHEN 1955 IS NULL THEN true
      WHEN 1955 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'B''nai Israel of Olney'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%307 w tabor rd%';

-- 19. B'nai Jacob: Starr & Manavon Sts
UPDATE public.addresses
SET start_year = 1966,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'B''nai Jacob'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%starr & manavon sts%';

-- 20. B'nai Joshua: 5343 Berks St
UPDATE public.addresses
SET start_year = 1961,
    end_year = 1973,
    is_current = CASE 
      WHEN 1973 IS NULL THEN true
      WHEN 1973 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'B''nai Joshua'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%5343 berks st%';

-- 21. B'nai Yitzchok: 243 E. Roosevelt Blvd
UPDATE public.addresses
SET start_year = 1953,
    end_year = 1985,
    is_current = CASE 
      WHEN 1985 IS NULL THEN true
      WHEN 1985 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'B''nai Yitzchok'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%243 e roosevelt blvd%';

-- 22. Bristol Jewish Center: 216 Pond St
UPDATE public.addresses
SET start_year = 1972,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Bristol Jewish Center'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%216 pond st%';

-- 23. Brith Achim: 481 South Gulph Rd
UPDATE public.addresses
SET start_year = 1979,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Brith Achim'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%481 south gulph rd%';

-- 24. Shir Ami-Bucks County Jewish Congregation: 101 Richboro Rd
UPDATE public.addresses
SET start_year = 1980,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Shir Ami-Bucks County Jewish Congregation'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%101 richboro rd%';

-- 25. Ezrath Israel: 69th St & Ogontz Ave
UPDATE public.addresses
SET start_year = 1950,
    end_year = 1969,
    is_current = CASE 
      WHEN 1969 IS NULL THEN true
      WHEN 1969 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Ezrath Israel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%69th st & ogontz ave%';

-- 26. Fox Chase Jewish Community Center: 7816 Halstead St
UPDATE public.addresses
SET start_year = 1964,
    end_year = 1984,
    is_current = CASE 
      WHEN 1984 IS NULL THEN true
      WHEN 1984 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Fox Chase Jewish Community Center'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%7816 halstead st%';

-- 27. Har Zion Temple: 54th St & Wynnefield Ave
UPDATE public.addresses
SET start_year = 1952,
    end_year = 1975,
    is_current = CASE 
      WHEN 1975 IS NULL THEN true
      WHEN 1975 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Har Zion Temple'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%54th st & wynnefield ave%';

-- 28. Har Zion Temple: 1500 Hagys Ford Rd
UPDATE public.addresses
SET start_year = 1992,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Har Zion Temple'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1500 hagys ford rd%';

-- 29. Kehilat HaNahar Also, [The] Little Shul by the River: 85 W Mechanic St
UPDATE public.addresses
SET start_year = 1999,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Kehilat HaNahar Also, [The] Little Shul by the River'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%85 w mechanic st%';

-- 30. Kesher Israel Congregation: 1000 Pottstown Pike
UPDATE public.addresses
SET start_year = 1988,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Kesher Israel Congregation'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1000 pottstown pike%';

-- 31. Kneses HaSefer- Educational Synagogue of Yardley: 1237 Edgewood Rd
UPDATE public.addresses
SET start_year = 1997,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Kneses HaSefer- Educational Synagogue of Yardley'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1237 edgewood rd%';

-- 32. Kol Emet: 19 South Main St
UPDATE public.addresses
SET start_year = 1999,
    end_year = 2000,
    is_current = CASE 
      WHEN 2000 IS NULL THEN true
      WHEN 2000 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Kol Emet'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%19 south main st%';

-- 33. Lower Merion Synagogue: 123 Old Lancaster Ave
UPDATE public.addresses
SET start_year = 1961,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Lower Merion Synagogue'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%123 old lancaster ave%';

-- 34. Mikveh Israel: 44 N 4th St
UPDATE public.addresses
SET start_year = 1975,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Mikveh Israel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%44 n 4th st%';

-- 35. Northeast Orthodox Congregation: 2117 Bleigh St
UPDATE public.addresses
SET start_year = 1961,
    end_year = 1976,
    is_current = CASE 
      WHEN 1976 IS NULL THEN true
      WHEN 1976 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Northeast Orthodox Congregation'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%2117 bleigh st%';

-- 36. Ohev Shalom: 2 Chester Rd
UPDATE public.addresses
SET start_year = 1965,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Ohev Shalom'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%2 chester rd%';

-- 37. Ohev Sholom of Bucks County: 944 Second Street Pike
UPDATE public.addresses
SET start_year = 1978,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Ohev Sholom of Bucks County'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%944 second street pike%';

-- 38. Old York Road Temple- Beth Am: 971 Old York Rd
UPDATE public.addresses
SET start_year = 1959,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Old York Road Temple- Beth Am'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%971 old york rd%';

-- 39. Or Shalom: 835 Darby-Paoli Rd
UPDATE public.addresses
SET start_year = 1985,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Or Shalom'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%835 darby-paoli rd%';

-- 40. Beth Tfilla of Overbrook Park: 7630 Woodbine Ave
UPDATE public.addresses
SET start_year = 1963,
    end_year = 2006,
    is_current = CASE 
      WHEN 2006 IS NULL THEN true
      WHEN 2006 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Beth Tfilla of Overbrook Park'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%7630 woodbine ave%';

-- 41. Oxford Circle Jewish Community Center-                  Beth Israel: 1009 Unruh Ave
UPDATE public.addresses
SET start_year = 1983,
    end_year = 2003,
    is_current = CASE 
      WHEN 2003 IS NULL THEN true
      WHEN 2003 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Oxford Circle Jewish Community Center-                  Beth Israel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1009 unruh ave%';

-- 42. Rhawnhurst Jewish Center: Hoffnagle & Summerdale Aves
UPDATE public.addresses
SET start_year = 1961,
    end_year = 1997,
    is_current = CASE 
      WHEN 1997 IS NULL THEN true
      WHEN 1997 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Rhawnhurst Jewish Center'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%hoffnagle & summerdale aves%';

-- 43. Adath Tikvah - Montefiore: 1630 Hoffnagle St
UPDATE public.addresses
SET start_year = 1998,
    end_year = 2002,
    is_current = CASE 
      WHEN 2002 IS NULL THEN true
      WHEN 2002 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Adath Tikvah - Montefiore'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1630 hoffnagle st%';

-- 44. Rodeph Shalom: 615 North Broad St
UPDATE public.addresses
SET start_year = 1936,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Rodeph Shalom'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%615 north broad st%';

-- 45. Society Hill Synagogue: 418 Spruce St
UPDATE public.addresses
SET start_year = 1961,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Society Hill Synagogue'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%418 spruce st%';

-- 46. Suburban Jewish Community Center-B'nai Aaron: 560 Mill Rd
UPDATE public.addresses
SET start_year = 1956,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Suburban Jewish Community Center-B''nai Aaron'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%560 mill rd%';

-- 47. Temple Isaiah: 8900 Roosevelt Blvd
UPDATE public.addresses
SET start_year = 1997,
    end_year = 2003,
    is_current = CASE 
      WHEN 2003 IS NULL THEN true
      WHEN 2003 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Temple Isaiah'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%8900 roosevelt blvd%';

-- 48. Temple Israel of Upper Darby: Bywood Ave & Walnut St
UPDATE public.addresses
SET start_year = 1951,
    end_year = 2001,
    is_current = CASE 
      WHEN 2001 IS NULL THEN true
      WHEN 2001 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Temple Israel of Upper Darby'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%bywood ave & walnut st%';

-- 49. Temple Judea of Bucks County: 300 Swamp Rd
UPDATE public.addresses
SET start_year = 1981,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Temple Judea of Bucks County'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%300 swamp rd%';

-- 50. Temple Shalom: 2901 Edgely Rd
UPDATE public.addresses
SET start_year = 1983,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Temple Shalom'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%2901 edgely rd%';

-- 51. Temple Sinai: Limekiln Pike & Dillon Rd
UPDATE public.addresses
SET start_year = 1979,
    end_year = 1992,
    is_current = CASE 
      WHEN 1992 IS NULL THEN true
      WHEN 1992 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Temple Sinai'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%limekiln pike & dillon rd%';

-- 52. Tiferes B'nai Israel: 2478 Street Rd
UPDATE public.addresses
SET start_year = 1971,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Tiferes B''nai Israel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%2478 street rd%';

-- 53. Tiferet Bet Israel: 1920 Skippack Pike
UPDATE public.addresses
SET start_year = 1990,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Tiferet Bet Israel'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%1920 skippack pike%';

-- 54. Tiferet Israel of Lower Bucks County: 2909 Bristol Rd
UPDATE public.addresses
SET start_year = 1980,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Tiferet Israel of Lower Bucks County'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%2909 bristol rd%';

-- 55. Tifereth Israel of Parkside: 3940 W Girard Ave
UPDATE public.addresses
SET start_year = 1951,
    end_year = 1966,
    is_current = CASE 
      WHEN 1966 IS NULL THEN true
      WHEN 1966 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Tifereth Israel of Parkside'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%3940 w girard ave%';

-- 56. Tikvoh Chadoshoh: 5364 W Chew Ave.
UPDATE public.addresses
SET start_year = 1956,
    end_year = 1988,
    is_current = CASE 
      WHEN 1988 IS NULL THEN true
      WHEN 1988 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Tikvoh Chadoshoh'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%5364 w chew ave%';

-- 57. Wynnefield Jewish Center: 5820 Overbrook Ave.
UPDATE public.addresses
SET start_year = 1950,
    end_year = 1969,
    is_current = CASE 
      WHEN 1969 IS NULL THEN true
      WHEN 1969 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Wynnefield Jewish Center'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%5820 overbrook ave%';

-- 58. Yavneh Synagogue: 2222 N 53rd St
UPDATE public.addresses
SET start_year = 1962,
    end_year = 1967,
    is_current = CASE 
      WHEN 1967 IS NULL THEN true
      WHEN 1967 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Yavneh Synagogue'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%2222 n 53rd st%';

-- 59. Young Israel of Elkins Park: 7715 Montgomery Ave
UPDATE public.addresses
SET start_year = 1993,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Young Israel of Elkins Park'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%7715 montgomery ave%';

-- 60. Young Israel of Oxford Circle: 6427 Large St
UPDATE public.addresses
SET start_year = 1957,
    end_year = 2008,
    is_current = CASE 
      WHEN 2008 IS NULL THEN true
      WHEN 2008 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Young Israel of Oxford Circle'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%6427 large st%';

-- 61. Young Israel of the Main Line: 273 Montgomery Ave
UPDATE public.addresses
SET start_year = 1996,
    end_year = 1999,
    is_current = CASE 
      WHEN 1999 IS NULL THEN true
      WHEN 1999 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Young Israel of the Main Line'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%273 montgomery ave%';

-- 62. Young Israel of the Main Line: 273 Montgomery Ave
UPDATE public.addresses
SET start_year = 2000,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Young Israel of the Main Line'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%273 montgomery ave%';

-- 63. Young People's Congregation - Shari Eli.: 728 W              Moyamensing Ave
UPDATE public.addresses
SET start_year = 1983,
    end_year = 2017,
    is_current = CASE 
      WHEN 2017 IS NULL THEN true
      WHEN 2017 >= 2024 THEN true
      ELSE false
    END
WHERE synagogue_id = (
    SELECT id FROM public.synagogues 
    WHERE name = 'Young People''s Congregation - Shari Eli.'
    LIMIT 1
  )
  AND LOWER(REPLACE(REPLACE(street_address, '.', ''), ',', '')) LIKE '%728 w              moyamensing%';

-- ============================================================================
-- SECTION 5: ADDRESS DATA - NEW HISTORICAL ADDRESSES
-- ============================================================================
-- Inserting 157 new historical address records
-- NOTE: These will NOT have geocoding (lat/lon) initially
--       A separate geocoding process will add coordinates

-- 1. Adath Israel of the Main Line: Montgomery and Wynnewood Avenues; Wynnewood, PA (1949-54)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Montgomery and Wynnewood Avenues',
  'Wynnewood',
  'PA',
  NULL,
  1949,
  54,
  false,
  true
FROM public.synagogues
WHERE name = 'Adath Israel of the Main Line'
LIMIT 1;

-- 2. Adath Israel: Old Lancaster Road and Highland Avenue; Merion Station, PA (1955-1978)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Old Lancaster Road and Highland Avenue',
  'Merion Station',
  'PA',
  NULL,
  1955,
  1978,
  false,
  true
FROM public.synagogues
WHERE name = 'Adath Israel'
LIMIT 1;

-- 3. Adath Israel: 250 N. Highland Avenue; Merion Station, PA  19066 (1998-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '250 N. Highland Avenue',
  'Merion Station',
  'PA',
  '19066',
  1998,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Adath Israel'
LIMIT 1;

-- 4. Adath Jeshurun: 509 Ashbourne Road; Elkins Park, PA (1960-1963)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '509 Ashbourne Road',
  'Elkins Park',
  'PA',
  NULL,
  1960,
  1963,
  false,
  true
FROM public.synagogues
WHERE name = 'Adath Jeshurun'
LIMIT 1;

-- 5. Adath Jeshurun: York and Ashbourne Roads; Elkins Park, PA (1964-1992)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'York and Ashbourne Roads',
  'Elkins Park',
  'PA',
  NULL,
  1964,
  1992,
  false,
  true
FROM public.synagogues
WHERE name = 'Adath Jeshurun'
LIMIT 1;

-- 6. Adath Shalom: Marshall and Ritner Streets; Philadelphia, PA (1961-2001)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Marshall and Ritner Streets',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  2001,
  false,
  true
FROM public.synagogues
WHERE name = 'Adath Shalom'
LIMIT 1;

-- 7. Ahavath Zion: 4334 Paul; Philadelphia, PA (1936-1957)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '4334 Paul',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1957,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 8. Ahavath Zion: Pennway and Friendship Streets; Philadelphia, PA (1959-1996)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Pennway and Friendship Streets',
  'Philadelphia',
  'PA',
  NULL,
  1959,
  1996,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 9. Ahavath Zion: 7101 Pennway Street; Philadelphia, PA (1977-2007)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '7101 Pennway Street',
  'Philadelphia',
  'PA',
  NULL,
  1977,
  2007,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavath Zion'
LIMIT 1;

-- 10. Ahavath Israel of Kensington.: 2304 North Mascher Street; Philadelphia, PA (1936)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2304 North Mascher Street',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1936,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavath Israel of Kensington.'
LIMIT 1;

-- 11. Ahavas Israel: 2302 North Mascher Street; Philadelphia, PA (1950-1981)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2302 North Mascher Street',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1981,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavas Israel'
LIMIT 1;

-- 12. Ahavas Israel: 7976 Summerdale Avenue; Philadelphia, PA (1982-1988)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '7976 Summerdale Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1982,
  1988,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavas Israel'
LIMIT 1;

-- 13. Aitz Chaim VeZichron Jacob: 32nd and Cumberland Streets; Philadelphia; PA (1961-1966)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '32nd and Cumberland Streets; Philadelphia; PA',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1966,
  false,
  true
FROM public.synagogues
WHERE name = 'Aitz Chaim VeZichron Jacob'
LIMIT 1;

-- 14. Tifereth Israel: Sixth and Morris Streets; Philadelphia, PA (1936-1975)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Sixth and Morris Streets',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1975,
  false,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel'
LIMIT 1;

-- 15. Beth Ahavah: 2116 Walnut Street; Philadelphia, PA (1980-1987)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2116 Walnut Street',
  'Philadelphia',
  'PA',
  NULL,
  1980,
  1987,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Ahavah'
LIMIT 1;

-- 16. Jewish Congregation of: 9201 Old Bustleton Avenue; Philadelphia, PA 19115-4684 (1957-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '9201 Old Bustleton Avenue; Philadelphia, PA 19115-4684',
  'Philadelphia',
  'PA',
  NULL,
  1957,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Jewish Congregation of'
LIMIT 1;

-- 17. Beth Am Israel: 5720 Beaumont Avenue; Philadelphia, PA (1950-1961)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5720 Beaumont Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1961,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 18. Beth Am Israel: 58th Street and Warrington Ave.; Philadelphia, PA (1961-1970)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '58th Street and Warrington Ave.',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1970,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 19. Beth Am Israel: 209 Forrest Avenue; Narberth, PA (1971-1972)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '209 Forrest Avenue',
  'Narberth',
  'PA',
  NULL,
  1971,
  1972,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Am Israel'
LIMIT 1;

-- 20. Beth Chaim Reform Congregation: 5220 Wynnefield Avenue; Philadelphia, PA (1950-1985)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5220 Wynnefield Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1985,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 21. Beth Chaim Reform Congregation: 1130 Vaughans Lane; Gladwyne, PA 19035 (1986-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1130 Vaughans Lane',
  'Gladwyne',
  'PA',
  '19035',
  1986,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Chaim Reform Congregation'
LIMIT 1;

-- 22. Beth El: 58th and Walnut Streets; Philadelphia, PA (1936-1969)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '58th and Walnut Streets',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1969,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 23. Beth Israel: Conshohocken and Country Club Roads; Philadelphia, PA (1957-1962)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Conshohocken and Country Club Roads',
  'Philadelphia',
  'PA',
  NULL,
  1957,
  1962,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 24. Brith Israel Congregation: 25 South Fifth Avenue; Coatesville, PA (1988-1994)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '25 South Fifth Avenue',
  'Coatesville',
  'PA',
  NULL,
  1988,
  1994,
  false,
  true
FROM public.synagogues
WHERE name = 'Brith Israel Congregation'
LIMIT 1;

-- 25. Beth Israel: Sumneytown Pike and Valley Forge Road; Lansdale, PA (1970-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Sumneytown Pike and Valley Forge Road',
  'Lansdale',
  'PA',
  NULL,
  1970,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 26. Beth Israel: 1080 Sumneytown Pike; Lansdale, PA (1983-1988)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1080 Sumneytown Pike',
  'Lansdale',
  'PA',
  NULL,
  1983,
  1988,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 27. Beth Judah: 5426 Sansom Street; Philadelphia, PA (1950-1967)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5426 Sansom Street',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1967,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Judah'
LIMIT 1;

-- 28. Beth HaMedrash Hare: 7926 Algon Avenue; Philadelphia PA (2008)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '7926 Algon Avenue; Philadelphia PA',
  'Philadelphia',
  'PA',
  NULL,
  2008,
  2008,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth HaMedrash Hare'
LIMIT 1;

-- 29. Beth Solomon: 2300 South Sixth Street; Philadelphia, PA (1961-1965)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2300 South Sixth Street',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1965,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 30. Dorshe Sholom Congregation: Foxcroft and Old York Roads; Elkins Park, PA (1955-1993)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Foxcroft and Old York Roads',
  'Elkins Park',
  'PA',
  NULL,
  1955,
  1993,
  false,
  true
FROM public.synagogues
WHERE name = 'Dorshe Sholom Congregation'
LIMIT 1;

-- 31. Dorshe Sholom Congregation: 8231 Old York Road; Elkins Park, PA 19027 (1994-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '8231 Old York Road',
  'Elkins Park',
  'PA',
  '19027',
  1994,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Dorshe Sholom Congregation'
LIMIT 1;

-- 32. Beth Solomon: 601 East Sedgwick Street; Philadelphia, PA (1961-1975)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '601 East Sedgwick Street',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1975,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 33. Beth El, Suburban: 11006 Audubon Avenue; Somerton, PA (1972-1998)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '11006 Audubon Avenue',
  'Somerton',
  'PA',
  NULL,
  1972,
  1998,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth El, Suburban'
LIMIT 1;

-- 34. Beth Tikvah: 1001 Paper Mill Road; Erdenheim, PA (1961-2010)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1001 Paper Mill Road',
  'Erdenheim',
  'PA',
  NULL,
  1961,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Tikvah'
LIMIT 1;

-- 35. Beth Tovim: 59th Street and Drexel Road; Philadelphia, PA (1964-1985)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '59th Street and Drexel Road',
  'Philadelphia',
  'PA',
  NULL,
  1964,
  1985,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Tovim'
LIMIT 1;

-- 36. Beth Tovim: 5871 Drexel Road; Philadelphia, PA 19131 (1986-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5871 Drexel Road',
  'Philadelphia',
  'PA',
  '19131',
  1986,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Tovim'
LIMIT 1;

-- 37. Beth Uziel: Rorer Street and Wyoming Avenue; Philadelphia, PA (1955-1995)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Rorer Street and Wyoming Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1955,
  1995,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Uziel'
LIMIT 1;

-- 38. Har Zion Temple: 318 South 19th Street; Philadelphia, PA (1949-1952)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '318 South 19th Street',
  'Philadelphia',
  'PA',
  NULL,
  1949,
  1952,
  false,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 39. Beth Zion-Beth Israel [Temple]: 18th and Spruce Streets; Philadelphia, PA (1953-1994)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '18th and Spruce Streets',
  'Philadelphia',
  'PA',
  NULL,
  1953,
  1994,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Zion-Beth Israel [Temple]'
LIMIT 1;

-- 40. B'nai Aaron: 5300 Euclid Avenue; Philadelphia, PA (1936-1963)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5300 Euclid Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1963,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Aaron'
LIMIT 1;

-- 41. B'nai Abraham: 521-527 Lombard Street; Philadelphia, PA (1980-2000)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '521-527 Lombard Street',
  'Philadelphia',
  'PA',
  NULL,
  1980,
  2000,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Abraham'
LIMIT 1;

-- 42. B'nai Abraham: 527 Lombard Street; Philadelphia, PA (2001-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '527 Lombard Street',
  'Philadelphia',
  'PA',
  NULL,
  2001,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Abraham'
LIMIT 1;

-- 43. B'nai Abraham Jewish Center: Willets and Eastview Roads; Philadelphia, PA (1962-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Willets and Eastview Roads',
  'Philadelphia',
  'PA',
  NULL,
  1962,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Abraham Jewish Center'
LIMIT 1;

-- 44. B'nai Israel of Olney: Tenth and Ruscomb Streets; Philadelphia, PA (1951-1975)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Tenth and Ruscomb Streets',
  'Philadelphia',
  'PA',
  NULL,
  1951,
  1975,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Israel of Olney'
LIMIT 1;

-- 45. B'nai Israel of Olney: Tenth and Rockland Streets; Philadelphia, PA (1956-1961)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Tenth and Rockland Streets',
  'Philadelphia',
  'PA',
  NULL,
  1956,
  1961,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Israel of Olney'
LIMIT 1;

-- 46. B'nai Jacob: 1145 Gilham Street; Philadelphia, PA (1961-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1145 Gilham Street',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Jacob'
LIMIT 1;

-- 47. B'nai Jeshurun Ahavas Chesed: Stenton Avenue and Dorset Street; Philadelphia, PA (1959-1972)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Stenton Avenue and Dorset Street',
  'Philadelphia',
  'PA',
  NULL,
  1959,
  1972,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Jeshurun Ahavas Chesed'
LIMIT 1;

-- 48. B'nai Moishe: 2339 North 31st Street; Philadelphia, PA (1961-1968)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2339 North 31st Street',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1968,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Moishe'
LIMIT 1;

-- 49. B'nai Torah: Bustleton Avenue and Lawler Street; Philadelphia, PA (1970)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Bustleton Avenue and Lawler Street',
  'Philadelphia',
  'PA',
  NULL,
  1970,
  1970,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Torah'
LIMIT 1;

-- 50. B'nai Sholom: 4850 North Seventh Street; Philadelphia, PA (1960-1973)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '4850 North Seventh Street',
  'Philadelphia',
  'PA',
  NULL,
  1960,
  1973,
  false,
  true
FROM public.synagogues
WHERE name = 'B''nai Sholom'
LIMIT 1;

-- 51. Ahavas Torah Congregation: 3620 Morrell Avenue; Philadelphia, PA (1962-1965)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '3620 Morrell Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1962,
  1965,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavas Torah Congregation'
LIMIT 1;

-- 52. Ahavas Torah Congregation: 11082 Knights Road; Philadelphia, PA (1966-1976)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '11082 Knights Road',
  'Philadelphia',
  'PA',
  NULL,
  1966,
  1976,
  false,
  true
FROM public.synagogues
WHERE name = 'Ahavas Torah Congregation'
LIMIT 1;

-- 53. Bristol Jewish Center: 215 Bond Street; Bristol, PA (1962-1971)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '215 Bond Street',
  'Bristol',
  'PA',
  NULL,
  1962,
  1971,
  false,
  true
FROM public.synagogues
WHERE name = 'Bristol Jewish Center'
LIMIT 1;

-- 54. Beth Israel: "D" Street and Roosevelt Blvd.; Philadelphia, PA (1936-1989)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '"D" Street and Roosevelt Blvd.',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1989,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Israel'
LIMIT 1;

-- 55. Brotherhood Temple Achim: 700 Moore Road; King of Prussia, PA (1975-1978)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '700 Moore Road',
  'King of Prussia',
  'PA',
  NULL,
  1975,
  1978,
  false,
  true
FROM public.synagogues
WHERE name = 'Brotherhood Temple Achim'
LIMIT 1;

-- 56. Shir Ami-Bucks County Jewish Congregation: PO Box 35; Richboro, PA (1977-1979)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'PO Box 35',
  'Richboro',
  'PA',
  NULL,
  1977,
  1979,
  false,
  true
FROM public.synagogues
WHERE name = 'Shir Ami-Bucks County Jewish Congregation'
LIMIT 1;

-- 57. Community Torah of Bucks County.: 944 Second Street Pike; Richboro, PA (2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '944 Second Street Pike',
  'Richboro',
  'PA',
  NULL,
  2017,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Community Torah of Bucks County.'
LIMIT 1;

-- 58. East Lane Temple: 1100 Oak Lane Avenue; Philadelphia, PA (1950-1972)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1100 Oak Lane Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1972,
  false,
  true
FROM public.synagogues
WHERE name = 'East Lane Temple'
LIMIT 1;

-- 59. East Lane Temple: Cedarbrook Hill; Wyncote, PA (1973-1992)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Cedarbrook Hill',
  'Wyncote',
  'PA',
  NULL,
  1973,
  1992,
  false,
  true
FROM public.synagogues
WHERE name = 'East Lane Temple'
LIMIT 1;

-- 60. Greater Northeast Congregation: 11001 Bustleton Avenue; Philadelphia, PA (1982-1998)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '11001 Bustleton Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1982,
  1998,
  false,
  true
FROM public.synagogues
WHERE name = 'Greater Northeast Congregation'
LIMIT 1;

-- 61. Fox Chase Jewish Community Center: Borbeck and Ferndale Streets; Philadelphia, PA (1961)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Borbeck and Ferndale Streets',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1961,
  false,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 62. Germantown Jewish Center: Lincoln Drive and Ellet Street; Philadelphia, PA (1949-1993)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Lincoln Drive and Ellet Street',
  'Philadelphia',
  'PA',
  NULL,
  1949,
  1993,
  false,
  true
FROM public.synagogues
WHERE name = 'Germantown Jewish Center'
LIMIT 1;

-- 63. Germantown Jewish Center: 400 West Ellet Street; Philadelphia, PA 19119 (1994-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '400 West Ellet Street',
  'Philadelphia',
  'PA',
  '19119',
  1994,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Germantown Jewish Center'
LIMIT 1;

-- 64. Har Zion Temple: 54th and Woodcrest Avenue; Philadelphia, PA (1936-1949)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '54th and Woodcrest Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1949,
  false,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 65. Har Zion Temple: 2258 Georges Lane; Philadelphia, PA (1950-1951)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2258 Georges Lane',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1951,
  false,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 66. Har Zion Temple: Hagys Ford Road at Hollow Road; Penn Valley, PA 19072 (1976-1991)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Hagys Ford Road at Hollow Road',
  'Penn Valley',
  'PA',
  '19072',
  1976,
  1991,
  false,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 67. Har Zion Temple: County Line and Matsonford Road; Radnor, PA (1970-1973)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'County Line and Matsonford Road',
  'Radnor',
  'PA',
  NULL,
  1970,
  1973,
  false,
  true
FROM public.synagogues
WHERE name = 'Har Zion Temple'
LIMIT 1;

-- 68. Kehilat Chaverim: 4801 Neshaminy Boulevard; Bensalem, PA (1997)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '4801 Neshaminy Boulevard',
  'Bensalem',
  'PA',
  NULL,
  1997,
  1997,
  false,
  true
FROM public.synagogues
WHERE name = 'Kehilat Chaverim'
LIMIT 1;

-- 69. Kehilat Chaverim: 4242 Neshaminy Boulevard; Bensalem, PA (1998-2010)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '4242 Neshaminy Boulevard',
  'Bensalem',
  'PA',
  NULL,
  1998,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Kehilat Chaverim'
LIMIT 1;

-- 70. Kneseth Chai: 702 Sharon Lane; Philadelphia, PA (1983-1984)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '702 Sharon Lane',
  'Philadelphia',
  'PA',
  NULL,
  1983,
  1984,
  false,
  true
FROM public.synagogues
WHERE name = 'Kneseth Chai'
LIMIT 1;

-- 71. Kneseth Chai: 44 Kingsciere Drive; Southampton, PA (1985)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '44 Kingsciere Drive',
  'Southampton',
  'PA',
  NULL,
  1985,
  1985,
  false,
  true
FROM public.synagogues
WHERE name = 'Kneseth Chai'
LIMIT 1;

-- 72. Keneseth Israel: 1723 North Broad Street; Philadelphia, PA (1950-1956)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1723 North Broad Street',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1956,
  false,
  true
FROM public.synagogues
WHERE name = 'Keneseth Israel'
LIMIT 1;

-- 73. Kesher Israel Congregation: 206 North Church Street; West Chester, PA (1973-1987)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '206 North Church Street',
  'West Chester',
  'PA',
  NULL,
  1973,
  1987,
  false,
  true
FROM public.synagogues
WHERE name = 'Kesher Israel Congregation'
LIMIT 1;

-- 74. Keneseth Israel: 984 North Marshall Street; Philadelphia, PA (1950-1971)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '984 North Marshall Street',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1971,
  false,
  true
FROM public.synagogues
WHERE name = 'Keneseth Israel'
LIMIT 1;

-- 75. Kerem Israel Anshe Sefard: 6716 Bustleton Avenue; Philadelphia, PA (1977-1991)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '6716 Bustleton Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1977,
  1991,
  false,
  true
FROM public.synagogues
WHERE name = 'Kerem Israel Anshe Sefard'
LIMIT 1;

-- 76. Kneses HaSefer- Educational Synagogue of Yardley: 31 West College Avenue; Yardley, PA (1989-1990)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '31 West College Avenue',
  'Yardley',
  'PA',
  NULL,
  1989,
  1990,
  false,
  true
FROM public.synagogues
WHERE name = 'Kneses HaSefer- Educational Synagogue of Yardley'
LIMIT 1;

-- 77. Kneses HaSefer- Educational Synagogue of Yardley: 64 South Main Street; Yardley, PA (1992-1996)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '64 South Main Street',
  'Yardley',
  'PA',
  NULL,
  1992,
  1996,
  false,
  true
FROM public.synagogues
WHERE name = 'Kneses HaSefer- Educational Synagogue of Yardley'
LIMIT 1;

-- 78. Kol Ami: Katz Chapel, Gratz College; Melrose Park, PA (1995-2005)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Katz Chapel',
  'Gratz College; Melrose Park',
  'PA',
  NULL,
  1995,
  2005,
  false,
  true
FROM public.synagogues
WHERE name = 'Kol Ami'
LIMIT 1;

-- 79. Kol Ami: 8201 High School Road; Elkins Park, PA (2006-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '8201 High School Road',
  'Elkins Park',
  'PA',
  NULL,
  2006,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Kol Ami'
LIMIT 1;

-- 80. Kol Emet: 1360 Oxford Valley Road; Yardley, PA (2001-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1360 Oxford Valley Road',
  'Yardley',
  'PA',
  NULL,
  2001,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Kol Emet'
LIMIT 1;

-- 81. Lenas HaZedek: 5944 Larchwood Avenue; Philadelphia, PA (1959-1967)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5944 Larchwood Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1959,
  1967,
  false,
  true
FROM public.synagogues
WHERE name = 'Lenas HaZedek'
LIMIT 1;

-- 82. Center City Reconstructionist Synagogue: Gershman Y, Broad and Pine Streets; Philadelphia, PA (2000-2002)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Gershman Y',
  'Broad and Pine Streets; Philadelphia',
  'PA',
  NULL,
  2000,
  2002,
  false,
  true
FROM public.synagogues
WHERE name = 'Center City Reconstructionist Synagogue'
LIMIT 1;

-- 83. Main Line Reform Temple: 235 Latches Lane; Merion, PA (1960)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '235 Latches Lane',
  'Merion',
  'PA',
  NULL,
  1960,
  1960,
  false,
  true
FROM public.synagogues
WHERE name = 'Main Line Reform Temple'
LIMIT 1;

-- 84. Mikveh Israel: Broad and York Streets; Philadelphia, PA (1936-1975)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Broad and York Streets',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1975,
  false,
  true
FROM public.synagogues
WHERE name = 'Mikveh Israel'
LIMIT 1;

-- 85. Mishkan Shalom: Darby and Liandillo Roads; Havertown, PA (1989-1991)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Darby and Liandillo Roads',
  'Havertown',
  'PA',
  NULL,
  1989,
  1991,
  false,
  true
FROM public.synagogues
WHERE name = 'Mishkan Shalom'
LIMIT 1;

-- 86. Mishkan Shalom: 5 Liandillo Road; Havertown, PA (1992-1995)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5 Liandillo Road',
  'Havertown',
  'PA',
  NULL,
  1992,
  1995,
  false,
  true
FROM public.synagogues
WHERE name = 'Mishkan Shalom'
LIMIT 1;

-- 87. Mishkan Shalom: 8836 Crefeld Street; Philadelphia, PA 19118 (1996-2001)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '8836 Crefeld Street',
  'Philadelphia',
  'PA',
  '19118',
  1996,
  2001,
  false,
  true
FROM public.synagogues
WHERE name = 'Mishkan Shalom'
LIMIT 1;

-- 88. Mishkan Shalom: 4101 Freeland Avenue; Philadelphia, PA 19128 (2002-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '4101 Freeland Avenue',
  'Philadelphia',
  'PA',
  '19128',
  2002,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Mishkan Shalom'
LIMIT 1;

-- 89. Israel Congregation: 325 W. 7th Street; Chester, PA (1961-1972)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '325 W. 7th Street',
  'Chester',
  'PA',
  NULL,
  1961,
  1972,
  false,
  true
FROM public.synagogues
WHERE name = 'Israel Congregation'
LIMIT 1;

-- 90. Mount Airy Jewish Community Center: 920 East Horter Street; Philadelphia, PA (1952-1954)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '920 East Horter Street',
  'Philadelphia',
  'PA',
  NULL,
  1952,
  1954,
  false,
  true
FROM public.synagogues
WHERE name = 'Mount Airy Jewish Community Center'
LIMIT 1;

-- 91. Ramat El: 6400 Ardleigh Street; Philadelphia, PA (1955-1964)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '6400 Ardleigh Street',
  'Philadelphia',
  'PA',
  NULL,
  1955,
  1964,
  false,
  true
FROM public.synagogues
WHERE name = 'Ramat El'
LIMIT 1;

-- 92. Ramat El: Ardleigh and Johnson Streets; Philadelphia, PA (1965-1983)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Ardleigh and Johnson Streets',
  'Philadelphia',
  'PA',
  NULL,
  1965,
  1983,
  false,
  true
FROM public.synagogues
WHERE name = 'Ramat El'
LIMIT 1;

-- 93. See, Neziner Congregation: 771 S. Second Street; Philadelphia, PA (1961-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '771 S. Second Street',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'See, Neziner Congregation'
LIMIT 1;

-- 94. Yeadon Jewish Community Center: 1541 Powell Street; Norristown, PA (1982-1988)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1541 Powell Street',
  'Norristown',
  'PA',
  NULL,
  1982,
  1988,
  false,
  true
FROM public.synagogues
WHERE name = 'Yeadon Jewish Community Center'
LIMIT 1;

-- 95. Ohel Jacob: Seventh Street and Columbia Avenue; Philadelphia, PA (1961-1964)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Seventh Street and Columbia Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1964,
  false,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob'
LIMIT 1;

-- 96. Ohel Jacob of Oxford Circle: Longshore and Castor Avenues; Philadelphia. PA (1961-1983)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Longshore and Castor Avenues; Philadelphia. PA',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1983,
  false,
  true
FROM public.synagogues
WHERE name = 'Ohel Jacob of Oxford Circle'
LIMIT 1;

-- 97. Ohev Shalom: Eighth and Welsh Streets; Chester, PA (1961-1963)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Eighth and Welsh Streets',
  'Chester',
  'PA',
  NULL,
  1961,
  1963,
  false,
  true
FROM public.synagogues
WHERE name = 'Ohev Shalom'
LIMIT 1;

-- 98. Ohev Shalom: Chester and Providence Roads; Chester, PA (1964)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Chester and Providence Roads',
  'Chester',
  'PA',
  NULL,
  1964,
  1964,
  false,
  true
FROM public.synagogues
WHERE name = 'Ohev Shalom'
LIMIT 1;

-- 99. Ohev Zedek: 1355 North Seventh Street; Philadelphia, PA (1951-1959)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1355 North Seventh Street',
  'Philadelphia',
  'PA',
  NULL,
  1951,
  1959,
  false,
  true
FROM public.synagogues
WHERE name = 'Ohev Zedek'
LIMIT 1;

-- 100. Ohev Zedek: 1201 E. Mt. Pleasant Avenue; Philadelphia, PA (1961-1977)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1201 E. Mt. Pleasant Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1977,
  false,
  true
FROM public.synagogues
WHERE name = 'Ohev Zedek'
LIMIT 1;

-- 101. Yeadon Jewish Community Center: Manayunk and Krams Avenue; Philadelphia, PA (1949)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Manayunk and Krams Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1949,
  1949,
  false,
  true
FROM public.synagogues
WHERE name = 'Yeadon Jewish Community Center'
LIMIT 1;

-- 102. Or Ami. See also, Ivy Ridge Jewish Community Center: Ridge Pike between Harts Lane and Barren Hill Road; Lafayette Hills, PA (1961-1963)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Ridge Pike between Harts Lane and Barren Hill Road',
  'Lafayette Hills',
  'PA',
  NULL,
  1961,
  1963,
  false,
  true
FROM public.synagogues
WHERE name = 'Or Ami. See also, Ivy Ridge Jewish Community Center'
LIMIT 1;

-- 103. Or Ami. See also, Ivy Ridge Jewish Community Center: 708 Ivy Ridge Pike; Lafayette Hills, PA 19444 (1964-2010)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '708 Ivy Ridge Pike',
  'Lafayette Hills',
  'PA',
  '19444',
  1964,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Or Ami. See also, Ivy Ridge Jewish Community Center'
LIMIT 1;

-- 104. Or Shalom: PO Box 476; Wayne, PA (1975-1981)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'PO Box 476',
  'Wayne',
  'PA',
  NULL,
  1975,
  1981,
  false,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 105. Or Shalom: 139 E. Lancaster Ave.; Wayne, PA (1982-1984)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '139 E. Lancaster Ave.',
  'Wayne',
  'PA',
  NULL,
  1982,
  1984,
  false,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 106. Oxford Circle Jewish Community Center-                  Beth Israel: 6645 Castor Avenue; Philadelphia, PA (1951-1952)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '6645 Castor Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1951,
  1952,
  false,
  true
FROM public.synagogues
WHERE name = 'Oxford Circle Jewish Community Center-                  Beth Israel'
LIMIT 1;

-- 107. Oxford Circle Jewish Community Center-                  Beth Israel: Algon and Unruh Avenues; Philadelphia, PA (1953-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Algon and Unruh Avenues',
  'Philadelphia',
  'PA',
  NULL,
  1953,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'Oxford Circle Jewish Community Center-                  Beth Israel'
LIMIT 1;

-- 108. Pennypack Jewish Community Center: 2605 Welch Road; Philadelphia, PA (1963-1997)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2605 Welch Road',
  'Philadelphia',
  'PA',
  NULL,
  1963,
  1997,
  false,
  true
FROM public.synagogues
WHERE name = 'Pennypack Jewish Community Center'
LIMIT 1;

-- 109. Pnai Or Religious Fellowship of Philadelphia-Jewish Renewal: 6757 Greene Street; Philadelphia, PA (2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '6757 Greene Street',
  'Philadelphia',
  'PA',
  NULL,
  2017,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Pnai Or Religious Fellowship of Philadelphia-Jewish Renewal'
LIMIT 1;

-- 110. Raim Ahuvim: 5854 Drexel Road; Philadelphia, PA 19131 (1961-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5854 Drexel Road',
  'Philadelphia',
  'PA',
  '19131',
  1961,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Raim Ahuvim'
LIMIT 1;

-- 111. Shaarei Eli: 512 Ritner Street; Philadelphia, PA (1961-1963)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '512 Ritner Street',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1963,
  false,
  true
FROM public.synagogues
WHERE name = 'Shaarei Eli'
LIMIT 1;

-- 112. Shaarei Eli: Eighth and Porter Streets; Philadelphia, PA (1964-1983)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Eighth and Porter Streets',
  'Philadelphia',
  'PA',
  NULL,
  1964,
  1983,
  false,
  true
FROM public.synagogues
WHERE name = 'Shaarei Eli'
LIMIT 1;

-- 113. Greater Northeast Congregation: Verree Road above Welch Road; Philadelphia, PA (1963-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Verree Road above Welch Road',
  'Philadelphia',
  'PA',
  NULL,
  1963,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'Greater Northeast Congregation'
LIMIT 1;

-- 114. Shaare Zedek.: 5301 Old York Road; Philadelphia, PA (1988-2001)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '5301 Old York Road',
  'Philadelphia',
  'PA',
  NULL,
  1988,
  2001,
  false,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 115. Shaare Zedek.: 52nd and Columbia Avenue; Philadelphia, PA (1936)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '52nd and Columbia Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1936,
  false,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 116. Shaare Zedek.: 51st Street and Columbia Avenue; Philadelphia, PA (1950-1975)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '51st Street and Columbia Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1975,
  false,
  true
FROM public.synagogues
WHERE name = 'Shaare Zedek.'
LIMIT 1;

-- 117. Shaari Israel: 2509 S. Fourth Street; Philadelphia, PA (1974-1977)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2509 S. Fourth Street',
  'Philadelphia',
  'PA',
  NULL,
  1974,
  1977,
  false,
  true
FROM public.synagogues
WHERE name = 'Shaari Israel'
LIMIT 1;

-- 118. Beth El: 7530 Lawler Street; Philadelphia, PA (2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '7530 Lawler Street',
  'Philadelphia',
  'PA',
  NULL,
  2017,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 119. Temple Isaiah: 8891 Old Farm Road; Philadelphia, PA (1996)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '8891 Old Farm Road',
  'Philadelphia',
  'PA',
  NULL,
  1996,
  1996,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Isaiah'
LIMIT 1;

-- 120. Temple Israel: 1951 Upland Way; Philadelphia, PA (1950-1954)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1951 Upland Way',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1954,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Israel'
LIMIT 1;

-- 121. Temple Judea of Bucks County: 38 Rogers Road; Furlong, PA (2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '38 Rogers Road',
  'Furlong',
  'PA',
  NULL,
  2017,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Judea of Bucks County'
LIMIT 1;

-- 122. Fox Chase Jewish Community Center: 4301 Tyson Avenue; Philadelphia, PA 19135 (1951-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '4301 Tyson Avenue',
  'Philadelphia',
  'PA',
  '19135',
  1951,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 123. Temple Shalom: Edgely Road off Mill Creek Parkway; Levittown, PA (1961-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Edgely Road off Mill Creek Parkway',
  'Levittown',
  'PA',
  NULL,
  1961,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 124. Temple Shalom: Large Street and Roosevelt Boulevard; Philadelphia, PA (1950-2003)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Large Street and Roosevelt Boulevard',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  2003,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 125. Temple Shalom: 55 North Church Lane; Broomall, PA 19008 (1961-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '55 North Church Lane',
  'Broomall',
  'PA',
  '19008',
  1961,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Shalom'
LIMIT 1;

-- 126. Temple Sinai: Washington Lane and Limekiln Pike; Philadelphia, PA (1950-1978)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Washington Lane and Limekiln Pike',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1978,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 127. Temple Sinai: 1401 Limekiln Pike; Dresher, PA (1993-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1401 Limekiln Pike',
  'Dresher',
  'PA',
  NULL,
  1993,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- 128. Temple Zion: 650 Edison Avenue; Sommerton, PA (1960-1963)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '650 Edison Avenue',
  'Sommerton',
  'PA',
  NULL,
  1960,
  1963,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Zion'
LIMIT 1;

-- 129. Tiferet Bet Israel: 1541 Powell Street; Norristown, PA (1989)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1541 Powell Street',
  'Norristown',
  'PA',
  NULL,
  1989,
  1989,
  false,
  true
FROM public.synagogues
WHERE name = 'Tiferet Bet Israel'
LIMIT 1;

-- 130. Tifereth Israel Anshe Lita: Sixth and Dickinson Streets; Philadelphia, PA (1961-1965)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Sixth and Dickinson Streets',
  'Philadelphia',
  'PA',
  NULL,
  1961,
  1965,
  false,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel Anshe Lita'
LIMIT 1;

-- 131. Tifereth Israel Anshe Lita: 2300 South Sixth Street; Philadelphia, PA (1966-1970)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2300 South Sixth Street',
  'Philadelphia',
  'PA',
  NULL,
  1966,
  1970,
  false,
  true
FROM public.synagogues
WHERE name = 'Tifereth Israel Anshe Lita'
LIMIT 1;

-- 132. Tikvas Israel: 41st Street and Parkside Avenue; Philadelphia, PA (1950-1969)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '41st Street and Parkside Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1950,
  1969,
  false,
  true
FROM public.synagogues
WHERE name = 'Tikvas Israel'
LIMIT 1;

-- 133. Tikvas Israel: 42nd and Viola Streets; Philadelphia, PA (1970-1971)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '42nd and Viola Streets',
  'Philadelphia',
  'PA',
  NULL,
  1970,
  1971,
  false,
  true
FROM public.synagogues
WHERE name = 'Tikvas Israel'
LIMIT 1;

-- 134. Tzedek V'Shalom: PO Box 863; Newtown, PA 18940 (1996-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'PO Box 863',
  'Newtown',
  'PA',
  '18940',
  1996,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Tzedek V''Shalom'
LIMIT 1;

-- 135. West Oak Lane Jewish Community Center: Thouron and Sedgewick Streets; Philadelphia, PA (1959-1976)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Thouron and Sedgewick Streets',
  'Philadelphia',
  'PA',
  NULL,
  1959,
  1976,
  false,
  true
FROM public.synagogues
WHERE name = 'West Oak Lane Jewish Community Center'
LIMIT 1;

-- 136. West Oak Lane Jewish Community Center: 115 West Avenue; Jenkintown, PA (1977)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '115 West Avenue',
  'Jenkintown',
  'PA',
  NULL,
  1977,
  1977,
  false,
  true
FROM public.synagogues
WHERE name = 'West Oak Lane Jewish Community Center'
LIMIT 1;

-- 137. West Philadelphia Jewish Community Center: 63rd and Ludlow Streets; Philadelphia, PA (1936-1961)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '63rd and Ludlow Streets',
  'Philadelphia',
  'PA',
  NULL,
  1936,
  1961,
  false,
  true
FROM public.synagogues
WHERE name = 'West Philadelphia Jewish Community Center'
LIMIT 1;

-- 138. Fox Chase Jewish Community Center: Conshohocken and Windermere Avenues; Philadelphia, PA (1964-1965)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Conshohocken and Windermere Avenues',
  'Philadelphia',
  'PA',
  NULL,
  1964,
  1965,
  false,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 139. Fox Chase Jewish Community Center: 3926 Conshohocken Avenue; Philadelphia, PA (1966-1977)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '3926 Conshohocken Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1966,
  1977,
  false,
  true
FROM public.synagogues
WHERE name = 'Fox Chase Jewish Community Center'
LIMIT 1;

-- 140. Congregation: 401 South Broad Street; Philadelphia, PA 19147 (1961-2008)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '401 South Broad Street',
  'Philadelphia',
  'PA',
  '19147',
  1961,
  2008,
  false,
  true
FROM public.synagogues
WHERE name = 'Congregation'
LIMIT 1;

-- 141. Yeadon Jewish Community Center: West Cobbs Creek Parkway and Whitby Avenue; Yeadon, PA (1961-1990)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'West Cobbs Creek Parkway and Whitby Avenue',
  'Yeadon',
  'PA',
  NULL,
  1961,
  1990,
  false,
  true
FROM public.synagogues
WHERE name = 'Yeadon Jewish Community Center'
LIMIT 1;

-- 142. Young Israel of Elkins Park: 503 Spring Road; Elikins Park, PA (1991-1992)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '503 Spring Road',
  'Elikins Park',
  'PA',
  NULL,
  1991,
  1992,
  false,
  true
FROM public.synagogues
WHERE name = 'Young Israel of Elkins Park'
LIMIT 1;

-- 143. Young People's Congregation - Shari Eli.: 342 Porter Street; Philadelphia (1955-1961)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '342 Porter Street; Philadelphia',
  'Philadelphia',
  'PA',
  NULL,
  1955,
  1961,
  false,
  true
FROM public.synagogues
WHERE name = 'Young People''s Congregation - Shari Eli.'
LIMIT 1;

-- 144. Young People's Congregation - Shari Eli.: Franklin Street and Moyamensing Avenue; Philadelphia, PA (1972-1982)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Franklin Street and Moyamensing Avenue',
  'Philadelphia',
  'PA',
  NULL,
  1972,
  1982,
  false,
  true
FROM public.synagogues
WHERE name = 'Young People''s Congregation - Shari Eli.'
LIMIT 1;

-- 145. Beth El: 2901 West Chapel Avenue; Cherry Hill, NJ 08002 (1970-)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2901 West Chapel Avenue; Cherry Hill, NJ',
  'Philadelphia',
  'PA',
  '08002',
  1970,
  NULL,
  true,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 146. Beth El: 8000 Main Street; Voorhees, NJ 08043 (2008-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '8000 Main Street; Voorhees, NJ',
  'Philadelphia',
  'PA',
  '08043',
  2008,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 147. Beth El: 642 Bellevue Avenue; Hammonton, NJ (2009-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '642 Bellevue Avenue; Hammonton, NJ',
  'Philadelphia',
  'PA',
  NULL,
  2009,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth El'
LIMIT 1;

-- 148. Brith Israel Congregation: 246 King Street at South Warner Street; Woodbury, NJ (2009-2010)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '246 King Street at South Warner Street; Woodbury, NJ',
  'Philadelphia',
  'PA',
  NULL,
  2009,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Brith Israel Congregation'
LIMIT 1;

-- 149. Beth Solomon: 19 White Horse Pike; Haddon Heights, NJ (1940-1953)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '19 White Horse Pike; Haddon Heights, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1940,
  1953,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 150. Beth Solomon: Green Street at White Horse Pike; Haddon Heights, NJ (1953-1989)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Green Street at White Horse Pike; Haddon Heights, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1953,
  1989,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 151. Beth Solomon: 1901 Kresson Road; Cherry Hill, NJ (1989-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1901 Kresson Road; Cherry Hill, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1989,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Beth Solomon'
LIMIT 1;

-- 152. Tiferes B'nai Israel: 212 High Street; Mt. Holly, NJ (1991-2011)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '212 High Street; Mt. Holly, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1991,
  2011,
  false,
  true
FROM public.synagogues
WHERE name = 'Tiferes B''nai Israel'
LIMIT 1;

-- 153. Chabad Lubavitch of Bucks County: 1925 Kresson Road; Cherry Hill, NJ (2008-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '1925 Kresson Road; Cherry Hill, NJ',
  'Philadelphia',
  'PA',
  NULL,
  2008,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Chabad Lubavitch of Bucks County'
LIMIT 1;

-- 154. Or Shalom: Church and Fellowship Roads; Mt, Laurel, NJ (1977)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  'Church and Fellowship Roads; Mt, Laurel, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1977,
  1977,
  false,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 155. Or Shalom: 850 Evesham Road; Cherry Hill, NJ (1991-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '850 Evesham Road; Cherry Hill, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1991,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Or Shalom'
LIMIT 1;

-- 156. Adath Emanu-el: 205 Elbow Lane; Mount Laurel, NJ (1997-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '205 Elbow Lane; Mount Laurel, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1997,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Adath Emanu-el'
LIMIT 1;

-- 157. Temple Sinai: 2101 New Albany Road; Cinnaminson, NJ (1969-2017)
INSERT INTO public.addresses (
  synagogue_id, street_address, city, state, zip_code,
  start_year, end_year, is_current, approved
)
SELECT 
  id,
  '2101 New Albany Road; Cinnaminson, NJ',
  'Philadelphia',
  'PA',
  NULL,
  1969,
  2017,
  false,
  true
FROM public.synagogues
WHERE name = 'Temple Sinai'
LIMIT 1;

-- ============================================================================
-- MERGE COMPLETE!
-- ============================================================================
-- 
-- Summary of changes:
--   ✓ Schema: Added start_year/end_year to addresses table
--   ✓ Rabbis: Updated 28 records with year ranges
--   ✓ Rabbis: Inserted 431 new rabbi records
--   ✓ Addresses: Updated 63 records with year ranges
--   ✓ Addresses: Inserted 157 new historical addresses
-- 
-- Next steps:
--   1. Run this SQL file in Supabase SQL Editor
--   2. Verify results with sample queries (see below)
--   3. Run geocoding script for 157 new addresses
-- 
-- ============================================================================

-- VERIFICATION QUERIES
-- Run these after the merge to verify everything worked:

-- 1. Check total rabbi count
SELECT COUNT(*) as total_rabbis FROM public.rabbis;
-- Expected: ~801 (370 + 431)

-- 2. Check rabbis with year ranges
SELECT COUNT(*) as rabbis_with_years 
FROM public.rabbis 
WHERE start_year IS NOT NULL OR end_year IS NOT NULL;
-- Expected: ~468

-- 3. Check total address count
SELECT COUNT(*) as total_addresses FROM public.addresses;
-- Expected: ~609 (452 + 157)

-- 4. Check addresses with year ranges
SELECT COUNT(*) as addresses_with_years 
FROM public.addresses 
WHERE start_year IS NOT NULL OR end_year IS NOT NULL;
-- Expected: ~220 (63 + 157)

-- 5. Sample: Adath Jeshurun complete history
SELECT 
  a.street_address,
  a.city,
  a.start_year,
  a.end_year,
  a.is_current
FROM public.addresses a
JOIN public.synagogues s ON a.synagogue_id = s.id
WHERE s.name = 'Adath Jeshurun'
ORDER BY a.start_year;
-- Expected: 4 addresses from 1936-2017

-- 6. Sample: Adath Jeshurun rabbi succession
SELECT 
  r.name,
  r.start_year,
  r.end_year
FROM public.rabbis r
JOIN public.synagogues s ON r.synagogue_id = s.id
WHERE s.name = 'Adath Jeshurun'
ORDER BY r.start_year;
-- Expected: 3 rabbis from 1936-2017

-- 7. Addresses needing geocoding
SELECT COUNT(*) as need_geocoding
FROM public.addresses
WHERE latitude IS NULL AND longitude IS NULL;
-- Expected: ~157 (the new historical addresses)

