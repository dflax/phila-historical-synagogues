# DATA READY FOR GEOCODING - UPDATED SUMMARY

## Changes Made ✅

### 1. Added 12 Unmatched Synagogues
Previously unmatched synagogues from Other sources are now included:
- (Congregation) Ahavas Torah-Rhawnhurst Torah Center
- (Congregation) Beth Or
- (Congregation) B'nai Jacob-Bershu Tov
- And 9 others

**New totals:**
- Synagogues: **706** (was 694)
- Addresses: **608** (was 592) 
- Rabbis: **820** (was 793)

### 2. Changed "Current" Representation to NULL

**Instead of "Current" string, now using NULL (empty) for end_year:**

- Addresses with NULL end_year: **367** (60%)
- Rabbis with NULL end_year: **248** (30%)

**This means:**
- `start_year=1990, end_year=NULL` → "1990-Present"
- `start_year=1990, end_year=2005` → "1990-2005"
- `start_year=NULL, end_year=NULL` → "Unknown"

**Website display logic:**
```javascript
function formatYearRange(start, end) {
  if (start && end) return `${start}-${end}`;
  if (start && !end) return `${start}-Present`;
  return "Unknown";
}
```

### 3. Created Google Geocoding Script

**New file: `geocode_master_addresses.py`**

This script will:
- ✅ Read master_addresses.csv
- ✅ Call Google Geocoding API for each address
- ✅ Extract clean components: street, city, state, ZIP
- ✅ Get lat/lon coordinates
- ✅ Save to master_addresses_geocoded.csv

---

## CURRENT FILES

### master_synagogues.csv (706 synagogues)
- `id` - UUID
- `name` - Canonical name
- `name_normalized` - For matching
- `founded_year` - From Dad's data
- `closed` - Closure info
- `neighborhood` - Location
- `data_sources` - Which sources had this
- `variant_count` - Name variants merged

### master_addresses.csv (608 addresses)
**Ready for geocoding!**
- `id` - UUID
- `synagogue_id` - Links to synagogue
- `synagogue_name` - For reference
- `street_address` - Current format (will be cleaned by Google)
- `city` - Current value (will be verified by Google)
- `state` - Current value (will be verified by Google)
- `zip_code` - Current value (will be filled by Google)
- `start_year` - When synagogue moved here
- `end_year` - NULL if current, year if historical
- `source` - other_addresses or dad_data

**Missing data:**
- Only 56 have ZIP codes (9%)
- No lat/lon coordinates yet

### master_rabbis.csv (820 rabbis)
- `id` - UUID
- `synagogue_id` - Links to synagogue
- `synagogue_name` - For reference
- `rabbi_name` - Full name
- `start_year` - When started
- `end_year` - NULL if current, year if ended
- `source` - other_rabbis or dad_history

### master_history.csv (347 entries)
- `id` - UUID
- `synagogue_id` - Links to synagogue
- `synagogue_name` - For reference
- `content` - History text
- `entry_type` - general or ethnic_origins

---

## NEXT STEP: GEOCODING

### Run the Geocoding Script

**Prerequisites:**
```bash
pip install requests pandas
```

**Setup:**
1. Open `geocode_master_addresses.py`
2. Replace `YOUR_GOOGLE_API_KEY_HERE` with your actual Google Maps API key
3. Make sure `master_addresses.csv` is in the same directory

**Run:**
```bash
python3 geocode_master_addresses.py
```

**What it does:**
- Processes all 608 addresses
- Calls Google Geocoding API (one per address)
- Takes ~1-2 hours (with 0.1s delay between requests)
- Creates `master_addresses_geocoded.csv` with:
  - Clean street addresses
  - Verified cities
  - Verified states
  - **ZIP codes** (Google will fill most of these!)
  - **Latitude** coordinates
  - **Longitude** coordinates
  - Formatted full address

**Progress output:**
```
[1/608] Adath Israel of the Main Line
  Input: Montgomery and Avenues, Wynnewood, PA
  ✓ Success: Montgomery Ave & Wynnewood Ave, Wynnewood, PA 19096
    Coordinates: 40.0123, -75.2456
    ZIP: 19096

[2/608] Adath Israel
  Input: Old Lancaster Road and Highland Avenue, Merion Station, PA
  ✓ Success: Old Lancaster Rd & Highland Ave, Merion Station, PA 19066
    Coordinates: 40.0089, -75.2234
    ZIP: 19066
...
```

**Expected results:**
- Success rate: **~90-95%** (545-575 addresses)
- ZIP codes filled: **~550** addresses (90%)
- Failed: **~30-60** addresses (vague intersections, demolished buildings)

### After Geocoding

You'll have:
- ✅ **master_addresses_geocoded.csv** - All addresses with lat/lon
- ✅ Failed addresses in separate file for manual review
- ✅ Ready to generate SQL imports

---

## AFTER GEOCODING: SQL GENERATION

Once geocoding completes, I'll:

1. **Generate SQL import scripts:**
   - `import_synagogues.sql` - 706 synagogues
   - `import_addresses.sql` - 608 addresses with geocoding
   - `import_rabbis.sql` - 820 rabbis
   - `import_history.sql` - 347 history entries

2. **Include verification queries:**
   - Check counts
   - Sample data
   - Validate relationships

3. **Ready for fresh Supabase import:**
   - Truncate all existing tables
   - Import new clean data
   - Verify in database
   - Test on website

---

## COST ESTIMATE

**Google Geocoding API:**
- 608 addresses × $0.005/request = **$3.04**
- Well under free tier (40,000 requests/month)
- **Estimated cost: FREE** ✅

---

## FILES IN OUTPUTS FOLDER

**Current data (for geocoding):**
- master_synagogues.csv
- master_addresses.csv  ← **Run geocoding on this**
- master_rabbis.csv
- master_history.csv

**Geocoding script:**
- geocode_master_addresses.py ← **Run this next**

**After geocoding, you'll have:**
- master_addresses_geocoded.csv ← **Use this for SQL import**
- addresses_failed_geocoding.csv ← **Manual review**

---

## READY TO PROCEED!

**Your next steps:**

1. **Review the 4 master CSV files** (optional - quick sanity check)

2. **Run geocoding:**
   ```bash
   cd /path/to/outputs
   python3 geocode_master_addresses.py
   ```

3. **Wait ~1-2 hours** (it will show progress)

4. **Let me know when done** and I'll:
   - Review geocoded results
   - Generate SQL imports
   - Prepare for Supabase replacement

---

**Questions?** Let me know if you need anything clarified!

Otherwise, go ahead and run the geocoding script! 🗺️
